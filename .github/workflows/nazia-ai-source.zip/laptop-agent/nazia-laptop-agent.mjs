// Nazia AI Laptop Companion Agent
// Run on your laptop: node nazia-laptop-agent.mjs
import { execFile } from 'node:child_process';
import os from 'node:os';

const SERVER_URL = process.env.NAZIA_SERVER_URL || 'https://ais-dev-3xy4krzsjzzrcekhtwz4uj-461480328344.asia-east1.run.app';
const DEVICE_ID = 'laptop-agent-' + os.hostname();
const DEVICE_NAME = 'Laptop Agent (' + os.hostname() + ')';

const SAFE_APPS = {
  chrome: process.platform === 'win32' ? ['cmd', ['/c', 'start', 'chrome']] : process.platform === 'darwin' ? ['open', ['-a', 'Google Chrome']] : ['google-chrome', []],
  explorer: process.platform === 'win32' ? ['explorer.exe', []] : process.platform === 'darwin' ? ['open', ['.']] : ['xdg-open', ['.']],
  notepad: process.platform === 'win32' ? ['notepad.exe', []] : process.platform === 'darwin' ? ['open', ['-a', 'TextEdit']] : ['gedit', []],
  calculator: process.platform === 'win32' ? ['calc.exe', []] : process.platform === 'darwin' ? ['open', ['-a', 'Calculator']] : ['gnome-calculator', []],
};

function openSafeUrl(url) {
  if (!/^https?:\/\//i.test(url)) return;
  if (process.platform === 'win32') {
    execFile('cmd', ['/c', 'start', '', url], () => {});
  } else if (process.platform === 'darwin') {
    execFile('open', [url], () => {});
  } else {
    execFile('xdg-open', [url], () => {});
  }
}

async function connect() {
  const streamUrl = `${SERVER_URL}/api/bridge/stream?deviceId=${encodeURIComponent(DEVICE_ID)}&deviceName=${encodeURIComponent(DEVICE_NAME)}&deviceType=agent`;
  console.log('Nazia Laptop Agent connecting to:', SERVER_URL);
  const resp = await fetch(streamUrl);
  if (!resp.ok || !resp.body) throw new Error('Bridge connect failed: ' + resp.status);

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let eventName = 'message';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';
    for (const line of lines) {
      if (line.startsWith('event:')) {
        eventName = line.slice(6).trim();
      } else if (line.startsWith('data:')) {
        const raw = line.slice(5).trim();
        if (eventName === 'command') {
          try {
            const cmd = JSON.parse(raw);
            console.log('Command from Jani:', cmd);
            if (cmd.action === 'open_url') openSafeUrl(cmd.payload);
            if (cmd.action === 'launch_app' && SAFE_APPS[cmd.payload]) {
              const [bin, args] = SAFE_APPS[cmd.payload];
              execFile(bin, args, () => {});
            }
          } catch {}
        }
        eventName = 'message';
      }
    }
  }
}

connect().catch((err) => {
  console.error(err);
  setTimeout(connect, 4000);
});
