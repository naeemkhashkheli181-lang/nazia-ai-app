export type NaziaStatus = 'idle' | 'listening' | 'thinking' | 'speaking';

export type AppMode = 'classic' | 'live' | 'control';

export interface BridgeDevice {
  id: string;
  name: string;
  deviceType: 'phone' | 'laptop' | 'agent';
  connectedAt: string;
}

export type ActiveToolModal =
  | null
  | 'chat'
  | 'reminders'
  | 'screen-assist'
  | 'phone-control'
  | 'camera'
  | 'settings'
  | 'menu'
  | 'visual-hub';

export type ActionGridTool =
  | 'chat'
  | 'voice'
  | 'search'
  | 'code'
  | 'screen'
  | 'phone';

export interface ReminderItem {
  id: string;
  title: string;
  dueText: string;
  dueTimestamp: number | null;
  completed: boolean;
  createdAt: string;
}

export interface MemoryProfile {
  ownerName: string;
  work: string;
  accounts: string;
  inverterSystem: string;
  deviceSetup: string;
  customFacts: string[];
}

export interface CharacterConfig {
  warmth: number;
  loyaltyMode: boolean;
  language: 'roman-urdu' | 'urdu-script' | 'english';
  voicePitch: number;
  voiceRate: number;
}

export type ShortcutActionType =
  | 'open_youtube'
  | 'system_check'
  | 'open_whatsapp'
  | 'open_maps'
  | 'weather_check'
  | 'list_reminders'
  | 'screen_control'
  | 'custom_prompt';

export interface CustomShortcut {
  id: string;
  keyword: string;
  action: ShortcutActionType;
  customPrompt?: string;
  confirmReply?: string;
  createdAt: string;
}

export interface NaziaPersistedState {
  memory: MemoryProfile;
  reminders: ReminderItem[];
  notes: string[];
  character: CharacterConfig;
  shortcuts: CustomShortcut[];
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'nazia';
  text: string;
  timestamp: string;
  mode?: ActionGridTool;
  sources?: GroundingSource[];
  imagePreview?: string;
}

export type VisualPresetId = 'starship' | 'blackhole' | 'fusion' | 'mars';

export interface VisualHubPreset {
  id: VisualPresetId;
  label: string;
  subtitle: string;
  prompt: string;
}

export interface PanelRect {
  x: number;
  y: number;
  w: number;
  h: number;
}
