import { useCallback, useEffect, useRef, useState } from 'react';
import {
  BellRing,
  Crown,
  Menu,
  MonitorSmartphone,
  PhoneIncoming,
  PictureInPicture2,
  Settings,
  Sparkles,
  X,
} from 'lucide-react';
import { ClassicDashboard } from './components/ClassicDashboard';
import { LiveWorkspace } from './components/LiveWorkspace';
import { PhoneScreenControl } from './components/PhoneScreenControl';
import { SplashScreen } from './components/SplashScreen';
import { ToolModals } from './components/ToolModals';
import { useNaziaVoice } from './hooks/useNaziaVoice';
import type {
  ActionGridTool,
  ActiveToolModal,
  AppMode,
  BridgeDevice,
  CharacterConfig,
  ChatMessage,
  GroundingSource,
  MemoryProfile,
  NaziaPersistedState,
  NaziaStatus,
  ReminderItem,
} from './types';
import {
  describeWeatherCode,
  formatRemindersSummary,
  parseNaziaCommand,
} from './utils/commandParser';

const DEFAULT_MEMORY: MemoryProfile = {
  ownerName: 'Jani',
  work: '',
  accounts: '',
  inverterSystem: '',
  deviceSetup: '',
  customFacts: [],
};

const DEFAULT_CHARACTER: CharacterConfig = {
  warmth: 95,
  loyaltyMode: true,
  language: 'roman-urdu',
  voicePitch: 1.12,
  voiceRate: 0.98,
};

const STARTUP_GREETING = 'Assalam o alaikum Jani, main Nazia, bolo kya karna hai?';

function nowTimeLabel(): string {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

interface ChatApiResponse {
  reply?: string;
  sources?: GroundingSource[];
  error?: string;
}

async function fetchChatWithRetry(payload: {
  prompt: string;
  mode: ActionGridTool;
  imageBase64?: string;
  history: Array<{ role: string; text: string }>;
}): Promise<{ ok: boolean; status: number; data: ChatApiResponse }> {
  const retryDelays = [0, 500, 1200];
  let lastError: unknown = null;

  for (let attempt = 0; attempt < retryDelays.length; attempt += 1) {
    if (retryDelays[attempt] > 0) {
      await new Promise((r) => setTimeout(r, retryDelays[attempt]));
    }
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 35000);
    try {
      const resp = await fetch('/api/chat', {
        method: 'POST',
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      window.clearTimeout(timeoutId);

      const rawText = await resp.text();
      let parsed: ChatApiResponse = {};
      try {
        parsed = rawText ? (JSON.parse(rawText) as ChatApiResponse) : {};
      } catch {
        // Non-JSON proxy/gateway response (e.g. temporary 502 HTML page): retry
        if (attempt < retryDelays.length - 1) continue;
      }

      if ((resp.status === 502 || resp.status === 503 || resp.status === 504) && attempt < retryDelays.length - 1) {
        continue;
      }
      return { ok: resp.ok, status: resp.status, data: parsed };
    } catch (err) {
      window.clearTimeout(timeoutId);
      lastError = err;
    }
  }

  throw lastError || new Error('Network unreachable');
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  const [mode, setMode] = useState<AppMode>('classic');
  const [activeTool, setActiveTool] = useState<ActionGridTool>('chat');
  const [activeModal, setActiveModal] = useState<ActiveToolModal>(null);
  const [isThinking, setIsThinking] = useState(false);

  const [memory, setMemory] = useState<MemoryProfile>(DEFAULT_MEMORY);
  const [reminders, setReminders] = useState<ReminderItem[]>([]);
  const [notes, setNotes] = useState<string[]>([]);
  const [character, setCharacter] = useState<CharacterConfig>(DEFAULT_CHARACTER);

  const [wakeWordEnabled, setWakeWordEnabled] = useState(false);
  const [awarenessOn, setAwarenessOn] = useState(false);
  const [inputText, setInputText] = useState('');
  const [latestBubbleText, setLatestBubbleText] = useState(STARTUP_GREETING);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'nazia',
      text: STARTUP_GREETING,
      timestamp: nowTimeLabel(),
    },
  ]);

  const [incomingCallActive, setIncomingCallActive] = useState(false);
  const [reminderAlertBanner, setReminderAlertBanner] = useState<string | null>(null);
  const [incomingRemoteUrl, setIncomingRemoteUrl] = useState<{ url: string; sender: string } | null>(
    null
  );
  const [bridgeDevices, setBridgeDevices] = useState<BridgeDevice[]>([]);
  const [pipActive, setPipActive] = useState(false);
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<{
    prompt: () => Promise<void>;
    userChoice: Promise<{ outcome: string }>;
  } | null>(null);

  const deviceInfoRef = useRef<{ id: string; name: string; type: 'phone' | 'laptop' }>({
    id: `dev-${Math.random().toString(36).slice(2, 9)}`,
    name: /android|iphone|ipad|mobile/i.test(navigator.userAgent) ? 'Jani Phone' : 'Jani Laptop',
    type: /android|iphone|ipad|mobile/i.test(navigator.userAgent) ? 'phone' : 'laptop',
  });
  const pipVideoRef = useRef<HTMLVideoElement | null>(null);
  const pipCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const pipStatusRef = useRef<NaziaStatus>('idle');
  const greetedRef = useRef(false);
  const firedRemindersRef = useRef<Set<string>>(new Set());
  const stateLoadedRef = useRef(false);

  useEffect(() => {
    const onBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredInstallPrompt(
        e as unknown as {
          prompt: () => Promise<void>;
          userChoice: Promise<{ outcome: string }>;
        }
      );
    };
    window.addEventListener('beforeinstallprompt', onBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', onBeforeInstall);
  }, []);

  // Connect real-time Phone <-> Laptop Control Bridge via SSE
  useEffect(() => {
    const dev = deviceInfoRef.current;
    const url = `/api/bridge/stream?deviceId=${encodeURIComponent(dev.id)}&deviceName=${encodeURIComponent(dev.name)}&deviceType=${dev.type}`;
    const es = new EventSource(url);

    es.addEventListener('devices', (ev) => {
      try {
        const list = JSON.parse((ev as MessageEvent).data) as BridgeDevice[];
        setBridgeDevices(list);
      } catch {
        // ignore
      }
    });

    es.addEventListener('command', (ev) => {
      try {
        const cmd = JSON.parse((ev as MessageEvent).data) as {
          action: string;
          payload: string;
          senderName: string;
        };
        if (cmd.action === 'speak' && cmd.payload) {
          setLatestBubbleText(cmd.payload);
          speakRef.current(cmd.payload);
        } else if (cmd.action === 'ring') {
          const msg = cmd.payload || 'Jani device dhoond rahe hain!';
          setReminderAlertBanner(msg);
          speakRef.current(msg);
        } else if (cmd.action === 'open_url' && /^https?:\/\//i.test(cmd.payload)) {
          setIncomingRemoteUrl({ url: cmd.payload, sender: cmd.senderName || 'Device' });
          const a = document.createElement('a');
          a.href = cmd.payload;
          a.target = '_blank';
          a.rel = 'noopener noreferrer';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        } else if (cmd.action === 'clipboard' && cmd.payload) {
          navigator.clipboard?.writeText(cmd.payload).catch(() => {});
          setLatestBubbleText(`Clipboard synced: ${cmd.payload.slice(0, 80)}`);
        }
      } catch {
        // ignore
      }
    });

    return () => {
      es.close();
    };
  }, []);

  // Keep mobile / Cloud Run connection warm when tab wakes up or stays active
  useEffect(() => {
    const pingHealth = () => {
      if (document.visibilityState === 'visible' && navigator.onLine) {
        fetch('/api/health', { cache: 'no-store' }).catch(() => {});
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible') pingHealth();
    };
    window.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('online', pingHealth);
    const interval = window.setInterval(pingHealth, 45000);
    return () => {
      window.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('online', pingHealth);
      window.clearInterval(interval);
    };
  }, []);

  // Load persisted user memory, reminders & notes on launch
  useEffect(() => {
    let cancelled = false;
    fetch('/api/state')
      .then((r) => (r.ok ? r.json() : null))
      .then((data: NaziaPersistedState | null) => {
        if (cancelled || !data) return;
        setMemory(data.memory || DEFAULT_MEMORY);
        setReminders(Array.isArray(data.reminders) ? data.reminders : []);
        setNotes(Array.isArray(data.notes) ? data.notes : []);
        setCharacter(data.character || DEFAULT_CHARACTER);
        stateLoadedRef.current = true;
      })
      .catch(() => {
        stateLoadedRef.current = true;
      });

    return () => {
      cancelled = true;
    };
  }, []);

  // Sync changes back to server when loaded
  const persistState = useCallback(
    (next: Partial<NaziaPersistedState>) => {
      if (!stateLoadedRef.current) return;
      fetch('/api/state', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(next),
      }).catch(() => {});
    },
    []
  );

  const appendNaziaReply = useCallback(
    (
      text: string,
      speakFn: (t: string) => void,
      sources?: GroundingSource[],
      toolMode?: ActionGridTool
    ) => {
      setLatestBubbleText(text);
      setMessages((prev) => [
        ...prev,
        {
          id: `nazia-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          role: 'nazia',
          text,
          timestamp: nowTimeLabel(),
          sources,
          mode: toolMode,
        },
      ]);
      speakFn(text);
    },
    []
  );

  // Voice hook wiring (circular handler ref for transcripts)
  const commandHandlerRef = useRef<
    (text?: string, toolOverride?: ActionGridTool, imageBase64?: string) => void
  >(() => {});

  const handleStatusChange = useCallback((_speaking: boolean, _listening: boolean) => {
    // State derived cleanly below
  }, []);

  const handleWakeWord = useCallback(() => {
    const reply = 'Ji Jani bolo, main sun rahi hoon.';
    setLatestBubbleText(reply);
    speakRef.current(reply);
  }, []);

  const handleTranscript = useCallback((spokenText: string) => {
    commandHandlerRef.current(spokenText);
  }, []);

  const voice = useNaziaVoice({
    character,
    wakeWordEnabled,
    onWakeWord: handleWakeWord,
    onTranscript: handleTranscript,
    onStatusChange: handleStatusChange,
  });

  const speakRef = useRef(voice.speak);
  speakRef.current = voice.speak;

  // Startup Urdu Greeting right after splash (with fallback on first tap if browser blocks autoplay)
  useEffect(() => {
    if (!showSplash && !greetedRef.current) {
      greetedRef.current = true;
      const timer = setTimeout(() => {
        voice.speak(STARTUP_GREETING);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [showSplash, voice]);

  // Reminder due-time checker
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      for (const rem of reminders) {
        if (
          !rem.completed &&
          rem.dueTimestamp &&
          rem.dueTimestamp <= now &&
          !firedRemindersRef.current.has(rem.id)
        ) {
          firedRemindersRef.current.add(rem.id);
          const alertText = `Jani waqt ho gaya hai! Yaad-dahani: ${rem.title}`;
          setReminderAlertBanner(alertText);
          setLatestBubbleText(alertText);
          voice.speak(alertText);
          if ('Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification('Nazia AI Reminder', { body: alertText });
            } catch {
              // ignore
            }
          }
        }
      }
    }, 15000);
    return () => clearInterval(interval);
  }, [reminders, voice]);

  const handleSendCommand = useCallback(
    async (raw?: string, toolOverride?: ActionGridTool, imageBase64?: string) => {
      const text = (raw ?? inputText).trim();
      const effectiveTool = toolOverride || activeTool;
      if (!text && !imageBase64) return;
      if (!raw) setInputText('');

      setMessages((prev) => [
        ...prev,
        {
          id: `user-${Date.now()}`,
          role: 'user',
          text: text || 'Screen / Camera inspect karein',
          timestamp: nowTimeLabel(),
          imagePreview: imageBase64,
        },
      ]);

      const parsed = parseNaziaCommand(text);

      // 1. Add Reminder locally + sync
      if (!imageBase64 && parsed.intent === 'add_reminder') {
        const newRem: ReminderItem = {
          id: `rem-${Date.now()}`,
          title: parsed.title,
          dueText: parsed.dueText,
          dueTimestamp: parsed.dueTimestamp,
          completed: false,
          createdAt: new Date().toISOString(),
        };
        const updated = [newRem, ...reminders];
        setReminders(updated);
        persistState({ reminders: updated });
        if ('Notification' in window && Notification.permission === 'default') {
          Notification.requestPermission().catch(() => {});
        }
        appendNaziaReply(parsed.confirmReply, voice.speak);
        return;
      }

      // 2. List Reminders
      if (!imageBase64 && parsed.intent === 'list_reminders') {
        const summary = formatRemindersSummary(reminders);
        appendNaziaReply(summary, voice.speak);
        setActiveModal('reminders');
        return;
      }

      // 3. Delete Reminder
      if (!imageBase64 && parsed.intent === 'delete_reminder') {
        const q = parsed.query.toLowerCase();
        const target = reminders.find(
          (r) => !q || r.title.toLowerCase().includes(q) || r.dueText.toLowerCase().includes(q)
        );
        if (!target) {
          appendNaziaReply('Jani woh reminder list mein nahi mila.', voice.speak);
          return;
        }
        const updated = reminders.filter((r) => r.id !== target.id);
        setReminders(updated);
        persistState({ reminders: updated });
        appendNaziaReply(
          `Theek hai Jani, "${target.title}" wala reminder delete kar diya hai.`,
          voice.speak
        );
        return;
      }

      // 4. Live Weather (Free Open-Meteo API)
      if (!imageBase64 && parsed.intent === 'weather') {
        setIsThinking(true);
        try {
          const resp = await fetch(`/api/weather?city=${encodeURIComponent(parsed.city)}`);
          const wx = (await resp.json()) as {
            city?: string;
            country?: string;
            tempC?: number;
            feelsLikeC?: number;
            humidity?: number;
            windKmh?: number;
            weatherCode?: number;
            error?: string;
          };
          if (!resp.ok || wx.tempC === undefined) {
            appendNaziaReply(
              `Jani ${parsed.city} ka mausam abhi fetch nahi ho saka: ${wx.error || 'network check karein.'}`,
              voice.speak
            );
          } else {
            const desc = describeWeatherCode(wx.weatherCode ?? 0);
            const msg = `Jani, aaj ${wx.city} (${wx.country}) ka mausam: ${desc}. Darja-e-hararat ${Math.round(
              wx.tempC
            )}°C hai (mehsoos ${Math.round(
              wx.feelsLikeC ?? wx.tempC
            )}°C), nami ${wx.humidity}% aur hawa ki raftar ${Math.round(
              wx.windKmh ?? 0
            )} km/h hai.`;
            appendNaziaReply(msg, voice.speak);
          }
        } catch {
          appendNaziaReply('Jani mausam check karte waqt internet error aaya.', voice.speak);
        } finally {
          setIsThinking(false);
        }
        return;
      }

      // 5. Quick App Control
      if (!imageBase64 && parsed.intent === 'open_app') {
        if (parsed.app === 'camera') {
          setActiveModal('camera');
          appendNaziaReply('Ji Jani, Camera khol diya hai.', voice.speak);
          return;
        }
        const appUrls: Record<string, string> = {
          youtube: 'https://www.youtube.com',
          whatsapp: 'https://wa.me/',
          browser: 'https://www.google.com',
          maps: 'https://maps.google.com',
        };
        const url = appUrls[parsed.app];
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        appendNaziaReply(
          `Ji Jani, ${parsed.app.toUpperCase()} khol rahi hoon.`,
          voice.speak
        );
        return;
      }

      // 6. System Check
      if (!imageBase64 && parsed.intent === 'system_check') {
        const nav = navigator as unknown as {
          getBattery?: () => Promise<{ level: number; charging: boolean }>;
          connection?: { effectiveType?: string; downlink?: number };
        };
        let batStr = 'Battery info browser ne hide ki hai';
        try {
          if (nav.getBattery) {
            const b = await nav.getBattery();
            batStr = `Battery ${Math.round(b.level * 100)}% (${b.charging ? 'charging par hai' : 'battery par chal rahi hai'})`;
          }
        } catch {
          // ignore
        }
        const netStr = nav.connection
          ? `Network ${nav.connection.effectiveType?.toUpperCase() || 'Active'} (${nav.connection.downlink ?? '--'} Mbps)`
          : navigator.onLine
          ? 'Internet connected hai'
          : 'Internet offline hai';
        const invStr = memory.inverterSystem
          ? `Inverter record: ${memory.inverterSystem}.`
          : 'Inverter details Settings Memory mein save kar sakte hain.';
        setActiveModal('phone-control');
        appendNaziaReply(
          `Jani system check mukamal hai: ${batStr}. ${netStr}. ${invStr}`,
          voice.speak
        );
        return;
      }

      // 7. Save personal memory directly
      if (!imageBase64 && parsed.intent === 'save_memory') {
        const updatedMem: MemoryProfile = {
          ...memory,
          customFacts: [...memory.customFacts, parsed.fact],
        };
        setMemory(updatedMem);
        persistState({ memory: updatedMem });
        appendNaziaReply(
          `Ji Jani, maine yaad rakh liya hai: "${parsed.fact}".`,
          voice.speak
        );
        return;
      }

      // 8. Call Alert
      if (!imageBase64 && parsed.intent === 'simulate_call') {
        setIncomingCallActive(true);
        appendNaziaReply('Jani call aayi hai! Kya speaker par baat karun?', voice.speak);
        return;
      }

      // 9. Gemini AI Backend Reasoning / Search / URL Analysis / Screen Vision (with 3x auto-retry)
      setIsThinking(true);
      try {
        const result = await fetchChatWithRetry({
          prompt: text,
          mode: effectiveTool,
          imageBase64,
          history: messages.slice(-8).map((m) => ({ role: m.role, text: m.text })),
        });
        if (!result.ok || !result.data.reply) {
          appendNaziaReply(
            `Jani AI server notice: ${result.data.error || 'Dobara koshish karein, main hazir hoon.'}`,
            voice.speak
          );
          return;
        }
        appendNaziaReply(result.data.reply, voice.speak, result.data.sources, effectiveTool);
      } catch {
        const offlineNote = !navigator.onLine
          ? 'Jani aap ke phone ka internet band lag raha hai — Wi-Fi ya mobile data check karein.'
          : 'Jani connection thora slow tha (3 bar koshish ki). Ek bar dubara "Send" dabayein.';
        appendNaziaReply(offlineNote, voice.speak);
      } finally {
        setIsThinking(false);
      }
    },
    [
      activeTool,
      appendNaziaReply,
      inputText,
      memory,
      messages,
      persistState,
      reminders,
      voice.speak,
    ]
  );

  commandHandlerRef.current = handleSendCommand;

  function handleSelectActionCard(tool: ActionGridTool) {
    setActiveTool(tool);
    if (tool === 'chat') {
      setActiveModal('chat');
    } else if (tool === 'voice') {
      if (voice.isListening) {
        voice.stopListening();
      } else {
        voice.startListening(wakeWordEnabled);
      }
    } else if (tool === 'search') {
      const msg = 'Jani AI Search mode active hai. Internet se jo poochna hai likhein ya bolein.';
      setLatestBubbleText(msg);
      voice.speak(msg);
    } else if (tool === 'code') {
      setActiveModal('screen-assist');
    } else if (tool === 'screen') {
      setMode('control');
    } else if (tool === 'phone') {
      setMode('control');
    }
  }

  function handleToggleMic() {
    voice.unlockAudio();
    if (voice.isListening) {
      voice.stopListening();
    } else {
      voice.startListening(wakeWordEnabled);
    }
  }

  function handleToggleWakeWord() {
    voice.unlockAudio();
    const next = !wakeWordEnabled;
    setWakeWordEnabled(next);
    if (next) {
      voice.speak('Ji Jani, Wake word Nazia active ho gaya hai.');
      window.setTimeout(() => {
        voice.startListening(true);
      }, 2200);
    } else {
      voice.stopListening();
    }
  }

  async function handleDownloadZip() {
    try {
      const resp = await fetch('/api/export-zip');
      if (!resp.ok) return;
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'nazia-ai-source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      appendNaziaReply(
        'Jani complete source code ZIP download ho gayi hai! Isay phone, laptop ya CodeAssist mein use kar sakte hain.',
        voice.speak
      );
    } catch {
      appendNaziaReply('Jani ZIP download karne mein error aaya.', voice.speak);
    }
  }

  function handleSimulateCall() {
    setIncomingCallActive(true);
    const callMsg = 'Jani call aayi hai! Speaker par baat karun?';
    setLatestBubbleText(callMsg);
    voice.speak(callMsg);
  }

  const currentStatus: NaziaStatus = isThinking
    ? 'thinking'
    : voice.isSpeaking
    ? 'speaking'
    : voice.isListening
    ? 'listening'
    : 'idle';

  pipStatusRef.current = currentStatus;

  // Render live Nazia hologram onto offscreen canvas for Floating Picture-in-Picture
  useEffect(() => {
    if (!pipActive) return;
    const canvas = pipCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.src = '/assets/nazia-portrait.png';
    let angle = 0;
    let rafId = 0;

    const draw = () => {
      const st = pipStatusRef.current;
      angle += st === 'speaking' ? 0.08 : st === 'thinking' ? 0.05 : 0.02;
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2 - 18;

      // Left & Right Holographic Ears (Kaan)
      const earPulse = st === 'listening' ? 1 + Math.sin(angle * 4) * 0.16 : 1;
      ctx.strokeStyle = st === 'listening' ? '#34d399' : '#22d3ee';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(cx - 86, cy, 14 * earPulse, Math.PI * 0.65, Math.PI * 1.35);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx + 86, cy, 14 * earPulse, -Math.PI * 0.35, Math.PI * 0.35);
      ctx.stroke();

      // Rotating neon ring
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle);
      ctx.beginPath();
      ctx.arc(0, 0, 74, 0, Math.PI * 1.45);
      ctx.strokeStyle = st === 'listening' ? '#34d399' : st === 'thinking' ? '#c084fc' : '#22d3ee';
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.restore();

      // Portrait circle
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, 62, 0, Math.PI * 2);
      ctx.clip();
      if (img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, cx - 62, cy - 62, 124, 124);
      }
      ctx.restore();

      // Glowing Holographic Eyes (Aankhein) reticles
      ctx.strokeStyle = st === 'listening' ? '#34d399' : '#67e8f9';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(cx - 22, cy - 18, 12, 8);
      ctx.strokeRect(cx + 10, cy - 18, 12, 8);

      // Animated Holographic Hands (Hath) + Mini Typing Bar
      const handBob = st === 'speaking' ? Math.sin(angle * 6) * 4 : Math.sin(angle * 2) * 2;
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(cx - 56, cy + 72 + handBob);
      ctx.lineTo(cx - 28, cy + 64 - handBob);
      ctx.moveTo(cx + 56, cy + 72 - handBob);
      ctx.lineTo(cx + 28, cy + 64 + handBob);
      ctx.stroke();

      ctx.fillStyle = '#e0f2fe';
      ctx.font = 'bold 15px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('NAZIA AI', cx, h - 28);
      ctx.fillStyle = '#38bdf8';
      ctx.font = '11px sans-serif';
      ctx.fillText(
        st === 'speaking' ? 'Boly & Typing...' : st === 'listening' ? 'Sun rahi hai...' : 'Aankh · Kaan · Hath',
        cx,
        h - 10
      );

      rafId = requestAnimationFrame(draw);
    };

    rafId = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafId);
  }, [pipActive]);

  async function togglePip() {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPipActive(false);
        return;
      }
      const canvas = pipCanvasRef.current;
      const video = pipVideoRef.current;
      if (!canvas || !video || !video.requestPictureInPicture) {
        setLatestBubbleText('Jani floating display ke liye Chrome browser use karein.');
        return;
      }
      // Paint immediate initial frame so video stream has valid dimensions before PiP request
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#020617';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#22d3ee';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('NAZIA AI', canvas.width / 2, canvas.height - 24);
      }
      setPipActive(true);
      const stream = canvas.captureStream(15);
      video.srcObject = stream;
      await video.play();
      await video.requestPictureInPicture();
      video.addEventListener(
        'leavepictureinpicture',
        () => {
          setPipActive(false);
        },
        { once: true }
      );
    } catch {
      setPipActive(false);
      setLatestBubbleText('Jani floating PiP abhi start nahi ho saka — dubara tap karein.');
    }
  }

  async function sendBridgeCommand(
    targetId: string,
    action: 'speak' | 'open_url' | 'clipboard' | 'ring' | 'launch_app',
    payload: string
  ) {
    try {
      await fetch('/api/bridge/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetId,
          action,
          payload,
          senderName: deviceInfoRef.current.name,
        }),
      });
    } catch {
      // ignore
    }
  }

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <div className="min-h-dvh w-full bg-[#020617] text-slate-100 relative overflow-x-hidden">
      {/* Ambient Cyberpunk / Jarvis Blue-Violet Glow */}
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(6,182,212,0.18),rgba(139,92,246,0.08)_42%,transparent_72%)]" />

      {/* Top Bar (3 compact zones: Menu | Crown + Nazia AI | Settings) */}
      <header className="sticky top-0 z-30 backdrop-blur-xl bg-[#020617]/85 border-b border-cyan-500/20">
        <div className="max-w-[1400px] mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => setActiveModal('menu')}
            aria-label="Open menu and memory"
            className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-cyan-300 hover:bg-cyan-500/10 transition-colors cursor-pointer shrink-0"
          >
            <Menu className="w-6 h-6" />
          </button>

          <div className="flex items-center gap-2 shrink-0">
            <Crown className="w-6 h-6 text-amber-400 drop-shadow-[0_0_12px_rgba(251,191,36,0.65)]" />
            <span className="font-display text-xl sm:text-2xl font-bold tracking-tight bg-gradient-to-r from-white via-cyan-200 to-violet-300 bg-clip-text text-transparent whitespace-nowrap">
              Nazia AI
            </span>
          </div>

          <button
            type="button"
            onClick={() => setActiveModal('settings')}
            aria-label="Open settings"
            className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-cyan-300 hover:bg-cyan-500/10 transition-colors cursor-pointer shrink-0"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>

        {/* Workspace Mode Bar (Classic vs Live vs Screen & Control) */}
        <div className="max-w-[1400px] mx-auto px-3 sm:px-6 pb-2.5 flex flex-wrap items-center justify-between gap-2">
          <div
            role="tablist"
            aria-label="Nazia AI Mode"
            className="inline-flex items-center p-1 rounded-xl border border-slate-800 bg-slate-900/90"
          >
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'classic'}
              onClick={() => setMode('classic')}
              className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                mode === 'classic'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Classic
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'live'}
              onClick={() => setMode('live')}
              className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                mode === 'live'
                  ? 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Live</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'control'}
              onClick={() => setMode('control')}
              className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                mode === 'control'
                  ? 'bg-gradient-to-r from-emerald-500 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <MonitorSmartphone className="w-3.5 h-3.5" />
              <span>Screen &amp; Control</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <button
              type="button"
              onClick={togglePip}
              aria-label="Float Nazia on display"
              className={`min-h-[34px] px-2.5 rounded-lg border font-medium flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                pipActive
                  ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                  : 'border-slate-800 bg-slate-900/80 text-slate-300 hover:border-cyan-500/50'
              }`}
            >
              <PictureInPicture2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Float Display</span>
            </button>

            <button
              type="button"
              onClick={handleToggleWakeWord}
              className={`min-h-[34px] px-2.5 rounded-lg border font-medium cursor-pointer whitespace-nowrap ${
                wakeWordEnabled
                  ? 'border-emerald-400/70 bg-emerald-500/15 text-emerald-200'
                  : 'border-slate-800 bg-slate-900/80 text-slate-300 hover:border-cyan-500/50'
              }`}
            >
              Wake: {wakeWordEnabled ? 'ON' : 'OFF'}
            </button>

            <button
              type="button"
              onClick={() => setActiveModal('reminders')}
              className="min-h-[34px] px-2.5 rounded-lg border border-slate-800 bg-slate-900/80 text-cyan-300 hover:border-cyan-500/50 flex items-center gap-1 cursor-pointer whitespace-nowrap"
            >
              <BellRing className="w-3.5 h-3.5" />
              <span className="tabular-nums">
                {reminders.filter((r) => !r.completed).length}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Incoming Call Alert Banner */}
      {incomingCallActive && (
        <div className="max-w-3xl mx-auto px-3 pt-3 relative z-20">
          <div className="rounded-2xl border border-emerald-400/70 bg-emerald-950/75 backdrop-blur-md p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-[0_0_25px_rgba(16,185,129,0.3)]">
            <div className="flex items-center gap-3">
              <PhoneIncoming className="w-5 h-5 text-emerald-300 shrink-0" />
              <div>
                <p className="text-sm font-bold text-white">Jani call aayi hai!</p>
                <p className="text-xs text-emerald-200">
                  Kya main speaker par insan jaisi Urdu mein baat karun?
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const answer =
                    'Assalam o alaikum! Ji farmayein, Jani abhi masroof hain, main unki personal assistant Nazia bol rahi hoon. Kya paigham de dun?';
                  setIncomingCallActive(false);
                  appendNaziaReply(answer, voice.speak);
                }}
                className="min-h-[38px] px-3.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-bold cursor-pointer"
              >
                Speak on Speaker
              </button>
              <button
                type="button"
                onClick={() => setIncomingCallActive(false)}
                aria-label="Dismiss call alert"
                className="min-w-[38px] min-h-[38px] rounded-xl bg-slate-900/80 text-slate-300 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Due Reminder Banner */}
      {reminderAlertBanner && (
        <div className="max-w-3xl mx-auto px-3 pt-3 relative z-20">
          <div className="rounded-2xl border border-cyan-400/70 bg-cyan-950/75 p-3.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <BellRing className="w-5 h-5 text-cyan-300 shrink-0" />
              <p className="text-sm font-medium text-white">{reminderAlertBanner}</p>
            </div>
            <button
              type="button"
              onClick={() => setReminderAlertBanner(null)}
              className="min-w-[36px] min-h-[36px] rounded-lg text-cyan-200 flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Remote Bridge Link Banner (ensures popup-blocked links remain 1-tap clickable) */}
      {incomingRemoteUrl && (
        <div className="max-w-3xl mx-auto px-3 pt-3 relative z-20">
          <div className="rounded-2xl border border-violet-400/70 bg-violet-950/75 p-3.5 flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-violet-200">
                {incomingRemoteUrl.sender} ne link bheja hai:
              </p>
              <p className="text-xs text-white truncate max-w-md">{incomingRemoteUrl.url}</p>
            </div>
            <div className="flex items-center gap-2">
              <a
                href={incomingRemoteUrl.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIncomingRemoteUrl(null)}
                className="min-h-[36px] px-3 rounded-xl bg-violet-500 text-white text-xs font-semibold flex items-center"
              >
                Open Link
              </a>
              <button
                type="button"
                onClick={() => setIncomingRemoteUrl(null)}
                className="min-w-[36px] min-h-[36px] rounded-lg text-violet-200 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Voice Error Notice */}
      {voice.voiceError && (
        <div className="max-w-3xl mx-auto px-3 pt-2 relative z-20">
          <div className="rounded-xl border border-amber-500/40 bg-amber-950/40 px-3.5 py-2 text-xs text-amber-200">
            {voice.voiceError}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="relative z-10 pt-4">
        {mode === 'classic' ? (
          <ClassicDashboard
            status={currentStatus}
            micLevel={voice.micLevel}
            isListening={voice.isListening}
            isSpeaking={voice.isSpeaking}
            interimText={voice.interimText}
            latestBubbleText={latestBubbleText}
            inputText={inputText}
            activeTool={activeTool}
            messages={messages}
            reminders={reminders}
            onInputChange={setInputText}
            onSendCommand={(txt, override) => handleSendCommand(txt, override)}
            onToggleMic={handleToggleMic}
            onSelectTool={handleSelectActionCard}
            onOpenModal={setActiveModal}
            onDeleteReminder={(id) => {
              const next = reminders.filter((r) => r.id !== id);
              setReminders(next);
              persistState({ reminders: next });
            }}
            onToggleReminder={(id) => {
              const next = reminders.map((r) =>
                r.id === id ? { ...r, completed: !r.completed } : r
              );
              setReminders(next);
              persistState({ reminders: next });
            }}
            onSpeakText={voice.speak}
          />
        ) : mode === 'live' ? (
          <LiveWorkspace
            status={currentStatus}
            micLevel={voice.micLevel}
            isListening={voice.isListening}
            interimText={voice.interimText}
            latestBubbleText={latestBubbleText}
            awarenessOn={awarenessOn}
            wakeWordEnabled={wakeWordEnabled}
            memory={memory}
            reminders={reminders}
            notes={notes}
            character={character}
            inputText={inputText}
            onInputChange={setInputText}
            onSendCommand={(txt, img) => handleSendCommand(txt, 'chat', img)}
            onToggleMic={handleToggleMic}
            onStartListening={() => voice.startListening(wakeWordEnabled)}
            onToggleAwareness={() => setAwarenessOn((v) => !v)}
            onSetAwareness={(v) => setAwarenessOn(v)}
            onToggleWakeWord={handleToggleWakeWord}
            onUpdateMemory={(next) => {
              setMemory(next);
              persistState({ memory: next });
            }}
            onUpdateCharacter={(next) => {
              setCharacter(next);
              persistState({ character: next });
            }}
            onAddNote={(note) => {
              const next = [note, ...notes];
              setNotes(next);
              persistState({ notes: next });
            }}
            onDeleteNote={(idx) => {
              const next = notes.filter((_, i) => i !== idx);
              setNotes(next);
              persistState({ notes: next });
            }}
            onDeleteReminder={(id) => {
              const next = reminders.filter((r) => r.id !== id);
              setReminders(next);
              persistState({ reminders: next });
            }}
            onSimulateCall={handleSimulateCall}
            onDownloadZip={handleDownloadZip}
            onOpenModal={setActiveModal}
          />
        ) : (
          <PhoneScreenControl
            status={currentStatus}
            micLevel={voice.micLevel}
            latestBubbleText={latestBubbleText}
            memory={memory}
            thisDeviceId={deviceInfoRef.current.id}
            thisDeviceType={deviceInfoRef.current.type}
            bridgeDevices={bridgeDevices}
            pipActive={pipActive}
            onTogglePip={togglePip}
            onToggleMic={handleToggleMic}
            onAnalyzeScreenImage={(prompt, img) => handleSendCommand(prompt, 'screen', img)}
            onSendBridgeCommand={sendBridgeCommand}
            onSimulateCall={handleSimulateCall}
          />
        )}
      </main>

      {/* Offscreen PiP Canvas & Video for Floating Nazia Display */}
      <canvas
        ref={pipCanvasRef}
        width={240}
        height={240}
        className="fixed -left-[9999px] top-0 w-[240px] h-[240px] opacity-0 pointer-events-none"
        aria-hidden="true"
      />
      <video
        ref={pipVideoRef}
        muted
        playsInline
        className="fixed -left-[9999px] top-0 w-[240px] h-[240px] opacity-0 pointer-events-none"
        aria-hidden="true"
      />

      {/* Interactive Modals / Drawers */}
      <ToolModals
        modal={activeModal}
        messages={messages}
        reminders={reminders}
        memory={memory}
        character={character}
        wakeWordEnabled={wakeWordEnabled}
        onClose={() => setActiveModal(null)}
        onSendCommand={(txt, m, img) => handleSendCommand(txt, m, img)}
        onAddReminder={(title, dueText) => {
          const item: ReminderItem = {
            id: `rem-${Date.now()}`,
            title,
            dueText,
            dueTimestamp: null,
            completed: false,
            createdAt: new Date().toISOString(),
          };
          const next = [item, ...reminders];
          setReminders(next);
          persistState({ reminders: next });
          appendNaziaReply(`Theek hai Jani, ${dueText} "${title}" yaad dila dungi.`, voice.speak);
        }}
        onDeleteReminder={(id) => {
          const next = reminders.filter((r) => r.id !== id);
          setReminders(next);
          persistState({ reminders: next });
        }}
        onToggleReminder={(id) => {
          const next = reminders.map((r) =>
            r.id === id ? { ...r, completed: !r.completed } : r
          );
          setReminders(next);
          persistState({ reminders: next });
        }}
        onUpdateMemory={(next) => {
          setMemory(next);
          persistState({ memory: next });
        }}
        onUpdateCharacter={(next) => {
          setCharacter(next);
          persistState({ character: next });
        }}
        onToggleWakeWord={handleToggleWakeWord}
        onSpeakText={voice.speak}
        onSimulateCall={handleSimulateCall}
        onDownloadZip={handleDownloadZip}
        canInstallPwa={Boolean(deferredInstallPrompt)}
        onInstallPwa={async () => {
          if (!deferredInstallPrompt) return;
          await deferredInstallPrompt.prompt();
          await deferredInstallPrompt.userChoice;
          setDeferredInstallPrompt(null);
        }}
      />
    </div>
  );
}
