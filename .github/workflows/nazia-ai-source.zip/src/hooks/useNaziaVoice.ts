import { useCallback, useEffect, useRef, useState } from 'react';
import type { CharacterConfig } from '../types';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface UseNaziaVoiceOptions {
  character: CharacterConfig;
  wakeWordEnabled: boolean;
  onWakeWord: () => void;
  onTranscript: (text: string) => void;
  onStatusChange: (speaking: boolean, listening: boolean) => void;
}

const SILENT_WAV_DATA_URI =
  'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';

export function useNaziaVoice({
  character,
  wakeWordEnabled,
  onWakeWord,
  onTranscript,
  onStatusChange,
}: UseNaziaVoiceOptions) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [interimText, setInterimText] = useState('');
  const [micLevel, setMicLevel] = useState(0);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const wakeActiveRef = useRef(wakeWordEnabled);
  const manualListenRef = useRef(false);

  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const audioUnlockedRef = useRef(false);
  const activeAudioUrlRef = useRef<string | null>(null);
  const speakSeqRef = useRef(0);
  const latestInterimRef = useRef('');
  const committedFinalRef = useRef(false);
  const resumeWakeTimerRef = useRef<number | null>(null);

  wakeActiveRef.current = wakeWordEnabled;

  useEffect(() => {
    onStatusChange(isSpeaking, isListening);
  }, [isSpeaking, isListening, onStatusChange]);

  const stopMicMeter = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
      audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }
    setMicLevel(0);
  }, []);

  const startMicMeter = useCallback(async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) return;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      const buffer = new Uint8Array(analyser.frequencyBinCount);

      const tick = () => {
        analyser.getByteFrequencyData(buffer);
        let sum = 0;
        for (let i = 0; i < buffer.length; i++) sum += buffer[i];
        const avg = sum / (buffer.length * 255);
        setMicLevel(Math.min(1, avg * 2.4));
        rafRef.current = requestAnimationFrame(tick);
      };
      rafRef.current = requestAnimationFrame(tick);
    } catch {
      // Microphone visualization is optional if recognition handles mic
    }
  }, []);

  const unlockAudio = useCallback(() => {
    if (typeof window === 'undefined') return;
    if (!audioElRef.current) {
      const el = new Audio();
      el.setAttribute('playsinline', 'true');
      el.preload = 'auto';
      audioElRef.current = el;
    }
    if (!audioUnlockedRef.current && audioElRef.current) {
      audioUnlockedRef.current = true;
      try {
        audioElRef.current.src = SILENT_WAV_DATA_URI;
        audioElRef.current.muted = true;
        audioElRef.current
          .play()
          .then(() => {
            if (audioElRef.current) {
              audioElRef.current.pause();
              audioElRef.current.muted = false;
            }
          })
          .catch(() => {
            audioUnlockedRef.current = false;
          });
      } catch {
        audioUnlockedRef.current = false;
      }
    }
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.getVoices();
        window.speechSynthesis.resume();
      } catch {
        // ignore
      }
    }
  }, []);

  // Unlock browser audio on first pointer/keyboard interaction so async AI replies always play aloud
  useEffect(() => {
    const handleFirstGesture = () => unlockAudio();
    window.addEventListener('pointerdown', handleFirstGesture, { passive: true });
    window.addEventListener('keydown', handleFirstGesture, { passive: true });
    return () => {
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
  }, [unlockAudio]);

  const pickFemaleVoice = useCallback((): SpeechSynthesisVoice | null => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    if (!voices.length) return null;

    const femaleHint = (v: SpeechSynthesisVoice) =>
      /female|woman|girl|uzma|atiya|lekh|swara|kalpana|heera|priya|zoya|samantha|victoria|karen|zira|aria|jenny|neerja|google हिन्दी|google urdu/i.test(
        v.name
      );

    const candidates = [
      voices.find((v) => v.lang.toLowerCase().startsWith('ur') && femaleHint(v)),
      voices.find((v) => v.lang.toLowerCase().startsWith('ur')),
      voices.find((v) => v.lang.toLowerCase().startsWith('hi') && femaleHint(v)),
      voices.find((v) => v.lang.toLowerCase().startsWith('hi')),
      voices.find((v) => v.lang.toLowerCase().startsWith('en') && femaleHint(v)),
      voices[0],
    ];
    return candidates.find(Boolean) || null;
  }, []);

  const stopListening = useCallback(() => {
    manualListenRef.current = false;
    latestInterimRef.current = '';
    try {
      recognitionRef.current?.stop();
    } catch {
      // ignore
    }
    setIsListening(false);
    setInterimText('');
    stopMicMeter();
  }, [stopMicMeter]);

  const startListeningRef = useRef<(continuousWake?: boolean) => void>(() => {});

  const startListening = useCallback(
    (continuousWake = false) => {
      unlockAudio();
      const win = window as unknown as {
        SpeechRecognition?: new () => SpeechRecognitionLike;
        webkitSpeechRecognition?: new () => SpeechRecognitionLike;
      };
      const RecognitionCtor = win.SpeechRecognition || win.webkitSpeechRecognition;
      if (!RecognitionCtor) {
        setSpeechSupported(false);
        setVoiceError(
          'Is browser mein voice recognition supported nahi hai. Chrome/Android par try karein ya neeche type karein.'
        );
        return;
      }

      if (resumeWakeTimerRef.current !== null) {
        window.clearTimeout(resumeWakeTimerRef.current);
        resumeWakeTimerRef.current = null;
      }

      setVoiceError(null);
      manualListenRef.current = true;
      latestInterimRef.current = '';
      committedFinalRef.current = false;

      try {
        recognitionRef.current?.stop();
      } catch {
        // ignore
      }

      const rec = new RecognitionCtor();
      rec.continuous = continuousWake;
      rec.interimResults = true;
      rec.lang = character.language === 'urdu-script' ? 'ur-PK' : 'en-PK';

      const handleSpokenText = (spoken: string) => {
        const cleaned = spoken.trim();
        if (!cleaned) return;
        const lower = cleaned.toLowerCase();

        // Wake word detection
        if (/^(nazia|naziya|naazia)\b[\s,.!?]*$/i.test(lower)) {
          onWakeWord();
          return;
        }

        if (continuousWake && !wakeActiveRef.current) return;
        onTranscript(cleaned);
        if (!continuousWake) {
          manualListenRef.current = false;
          setIsListening(false);
          setInterimText('');
          stopMicMeter();
        }
      };

      rec.onresult = (event: SpeechRecognitionEventLike) => {
        let finalChunk = '';
        let interimChunk = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const item = event.results[i];
          if (item.isFinal) {
            finalChunk += item[0].transcript;
          } else {
            interimChunk += item[0].transcript;
          }
        }
        const trimmedInterim = interimChunk.trim();
        latestInterimRef.current = trimmedInterim;
        setInterimText(trimmedInterim);

        const spoken = finalChunk.trim();
        if (spoken) {
          committedFinalRef.current = true;
          latestInterimRef.current = '';
          handleSpokenText(spoken);
        }
      };

      rec.onerror = (ev: { error: string }) => {
        if (ev.error === 'not-allowed') {
          setVoiceError('Jani, microphone permission allow karein taake main aap ki awaz sun sakun.');
          manualListenRef.current = false;
          setIsListening(false);
          stopMicMeter();
        } else if (ev.error !== 'no-speech' && ev.error !== 'aborted') {
          setVoiceError(`Voice error: ${ev.error}`);
        }
      };

      rec.onend = () => {
        // On Android Chrome, SpeechRecognition sometimes ends right after interim results without emitting isFinal
        if (!committedFinalRef.current && latestInterimRef.current) {
          const fallbackSpoken = latestInterimRef.current;
          latestInterimRef.current = '';
          committedFinalRef.current = true;
          handleSpokenText(fallbackSpoken);
          return;
        }

        if (wakeActiveRef.current && manualListenRef.current) {
          try {
            rec.start();
            return;
          } catch {
            // fall through
          }
        }
        setIsListening(false);
        setInterimText('');
        stopMicMeter();
      };

      recognitionRef.current = rec;
      try {
        rec.start();
        setIsListening(true);
        startMicMeter();
      } catch {
        setVoiceError('Mic start nahi ho saka, dobara tap karein.');
      }
    },
    [character.language, onTranscript, onWakeWord, startMicMeter, stopMicMeter, unlockAudio]
  );

  startListeningRef.current = startListening;

  const stopSpeaking = useCallback(() => {
    speakSeqRef.current += 1;
    if (audioElRef.current) {
      try {
        audioElRef.current.pause();
        audioElRef.current.currentTime = 0;
      } catch {
        // ignore
      }
    }
    if (activeAudioUrlRef.current) {
      URL.revokeObjectURL(activeAudioUrlRef.current);
      activeAudioUrlRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  const speakWithBrowserTts = useCallback(
    (cleanText: string, seq: number, onComplete: () => void) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        onComplete();
        return;
      }
      try {
        const synth = window.speechSynthesis;
        if (synth.speaking || synth.pending) {
          synth.cancel();
        }
        synth.resume();

        // Short delay avoids Chromium bug where cancel() cancels the newly queued utterance
        window.setTimeout(() => {
          if (seq !== speakSeqRef.current) return;
          const utter = new SpeechSynthesisUtterance(cleanText);
          const voice = pickFemaleVoice();
          if (voice) {
            utter.voice = voice;
            utter.lang = voice.lang;
          } else {
            utter.lang = character.language === 'urdu-script' ? 'ur-PK' : 'en-PK';
          }
          utter.pitch = character.voicePitch;
          utter.rate = character.voiceRate;

          utter.onstart = () => {
            if (seq === speakSeqRef.current) setIsSpeaking(true);
          };
          utter.onend = () => {
            if (seq === speakSeqRef.current) onComplete();
          };
          utter.onerror = () => {
            if (seq === speakSeqRef.current) onComplete();
          };

          setIsSpeaking(true);
          synth.resume();
          synth.speak(utter);
        }, 65);
      } catch {
        onComplete();
      }
    },
    [character.language, character.voicePitch, character.voiceRate, pickFemaleVoice]
  );

  const speak = useCallback(
    async (text: string) => {
      const cleanText = text
        .replace(/[*_`#]/g, '')
        .replace(/https?:\/\/\S+/g, 'link')
        .trim();
      if (!cleanText || typeof window === 'undefined') return;

      // Pause active mic/recognition before speaking so Android releases audio hardware to speaker
      const shouldResumeWake = wakeActiveRef.current && manualListenRef.current;
      try {
        recognitionRef.current?.stop();
      } catch {
        // ignore
      }
      stopMicMeter();
      setIsListening(false);
      setInterimText('');

      stopSpeaking();
      const mySeq = speakSeqRef.current;
      setIsSpeaking(true);

      const finishSpeech = () => {
        if (mySeq !== speakSeqRef.current) return;
        setIsSpeaking(false);
        if (shouldResumeWake && wakeActiveRef.current) {
          resumeWakeTimerRef.current = window.setTimeout(() => {
            if (wakeActiveRef.current) {
              startListeningRef.current(true);
            }
          }, 320);
        }
      };

      // 1. Primary AI Voice: Gemini 3.8 Flash Lite TTS (Real female Urdu audio)
      try {
        const controller = new AbortController();
        const tid = window.setTimeout(() => controller.abort(), 14000);
        const resp = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: cleanText }),
          signal: controller.signal,
        });
        window.clearTimeout(tid);

        if (mySeq !== speakSeqRef.current) return;

        if (resp.ok) {
          const data = (await resp.json()) as { audioBase64?: string; mimeType?: string };
          if (data.audioBase64 && mySeq === speakSeqRef.current) {
            const binary = atob(data.audioBase64);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
              bytes[i] = binary.charCodeAt(i);
            }
            const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
            const url = URL.createObjectURL(blob);
            activeAudioUrlRef.current = url;

            if (!audioElRef.current) {
              audioElRef.current = new Audio();
              audioElRef.current.setAttribute('playsinline', 'true');
            }
            const audio = audioElRef.current;
            audio.muted = false;
            audio.volume = 1;
            audio.playbackRate = Math.max(0.8, Math.min(1.25, character.voiceRate));
            audio.src = url;
            audio.onended = () => {
              if (activeAudioUrlRef.current === url) {
                URL.revokeObjectURL(url);
                activeAudioUrlRef.current = null;
              }
              finishSpeech();
            };
            audio.onerror = () => {
              if (activeAudioUrlRef.current === url) {
                URL.revokeObjectURL(url);
                activeAudioUrlRef.current = null;
              }
              speakWithBrowserTts(cleanText, mySeq, finishSpeech);
            };
            await audio.play();
            return;
          }
        }
      } catch {
        // Fall through cleanly to hardened browser speechSynthesis
      }

      if (mySeq !== speakSeqRef.current) return;
      // 2. Fallback Voice: Hardened Browser speechSynthesis
      speakWithBrowserTts(cleanText, mySeq, finishSpeech);
    },
    [character.voiceRate, speakWithBrowserTts, stopMicMeter, stopSpeaking]
  );

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
      const onVoicesChanged = () => window.speechSynthesis.getVoices();
      window.speechSynthesis.addEventListener?.('voiceschanged', onVoicesChanged);
      return () => {
        window.speechSynthesis.removeEventListener?.('voiceschanged', onVoicesChanged);
        stopListening();
        stopSpeaking();
      };
    }
    return () => {
      stopListening();
      stopSpeaking();
    };
  }, [stopListening, stopSpeaking]);

  return {
    isListening,
    isSpeaking,
    interimText,
    micLevel,
    speechSupported,
    voiceError,
    speak,
    stopSpeaking,
    startListening,
    stopListening,
    unlockAudio,
  };
}
