import type { ReminderItem } from '../types';

export type ParsedCommand =
  | {
      intent: 'add_reminder';
      title: string;
      dueText: string;
      dueTimestamp: number | null;
      confirmReply: string;
    }
  | { intent: 'list_reminders' }
  | { intent: 'delete_reminder'; query: string }
  | { intent: 'weather'; city: string }
  | { intent: 'open_app'; app: 'youtube' | 'whatsapp' | 'camera' | 'browser' | 'maps'; query?: string }
  | { intent: 'system_check' }
  | { intent: 'save_memory'; fact: string }
  | { intent: 'simulate_call' }
  | { intent: 'chat' };

export function parseNaziaCommand(rawInput: string): ParsedCommand {
  const text = rawInput.trim();
  const lower = text.toLowerCase();

  // 1. List reminders: "Nazia mujhe yaad dilao" or "pending reminders"
  if (
    /(mujhe\s+yaad\s+dilao|pending\s+reminders|reminders\s+dikhao|mere\s+tasks|list\s+reminders|yaad\s+dahani\s+list)/i.test(
      lower
    )
  ) {
    return { intent: 'list_reminders' };
  }

  // 2. Delete reminder
  if (
    /(delete|hatao|remove|cancel|khatam)\s+.*(reminder|task|yaad)/i.test(lower) ||
    /(reminder|task|yaad).*(delete|hatao|remove|cancel)/i.test(lower)
  ) {
    const cleaned = text
      .replace(/nazia/gi, '')
      .replace(/\b(delete|hatao|remove|cancel|khatam|karo|kardo|reminder|task|yaad|wala)\b/gi, '')
      .trim();
    return { intent: 'delete_reminder', query: cleaned };
  }

  // 3. Add reminder / task: "Nazia kal 5 baje yaad dilana", "task add karo"
  if (
    /(yaad\s+dila(?:na|o|do)?|remind\s+me|task\s+add|add\s+task|reminder\s+set|yaad\s+rakhna\s+ke)/i.test(
      lower
    )
  ) {
    const now = new Date();
    let dueTimestamp: number | null = null;
    let dueText = 'Aaj';

    const isTomorrow = /\b(kal|tomorrow)\b/i.test(lower);
    const minMatch = lower.match(/(\d+)\s*(min|minute|minutes|mint)\s*(baad|later|mein|me)?/i);
    const hrMatch = lower.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|bj)?/i);

    if (minMatch) {
      const mins = Math.max(1, Number(minMatch[1]));
      dueTimestamp = Date.now() + mins * 60_000;
      dueText = `${mins} minute baad`;
    } else if (hrMatch) {
      let hour = Number(hrMatch[1]);
      const minute = hrMatch[2] ? Number(hrMatch[2]) : 0;
      const suffix = (hrMatch[3] || '').toLowerCase();
      if (suffix === 'pm' && hour < 12) hour += 12;
      else if (suffix === 'am' && hour === 12) hour = 0;
      else if (suffix === 'baje' || suffix === 'bj' || !suffix) {
        if (hour >= 1 && hour <= 11 && /\b(shaam|raat|evening|night|dopahar|afternoon)\b/i.test(lower)) {
          hour += 12;
        } else if (hour >= 1 && hour <= 7 && !/\b(subah|morning|fajr)\b/i.test(lower)) {
          // Typical daytime/evening 5 baje -> 5 PM
          hour += 12;
        }
      }
      const target = new Date(now);
      if (isTomorrow) target.setDate(target.getDate() + 1);
      target.setHours(hour, minute, 0, 0);
      if (!isTomorrow && target.getTime() <= Date.now()) {
        target.setDate(target.getDate() + 1);
      }
      dueTimestamp = target.getTime();
      const formattedTime = target.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
      dueText = `${isTomorrow ? 'Kal' : 'Aaj'} ${formattedTime}`;
    } else if (isTomorrow) {
      const target = new Date(now);
      target.setDate(target.getDate() + 1);
      target.setHours(9, 0, 0, 0);
      dueTimestamp = target.getTime();
      dueText = 'Kal 9:00 AM';
    }

    let title = text
      .replace(/^nazia[\s,:-]*/i, '')
      .replace(/\b(kal|aaj|tomorrow|today)\b/gi, '')
      .replace(/\b\d{1,2}(:\d{2})?\s*(am|pm|baje|bj)?\b/gi, '')
      .replace(/\b\d+\s*(min|minute|minutes|mint)\s*(baad|later|mein|me)?\b/gi, '')
      .replace(/\b(yaad\s+dila(?:na|o|do)?|remind\s+me|task\s+add\s+karo|add\s+task|task\s+add|karo|karna|mujhe|ko|par|pe)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!title) {
      title = 'Ahem kaam / Yaad-dahani';
    }

    const confirmReply = `Theek hai Jani, ${dueText} "${title}" yaad dila dungi.`;
    return {
      intent: 'add_reminder',
      title,
      dueText,
      dueTimestamp,
      confirmReply,
    };
  }

  // 4. Weather check
  if (/(mausam|weather|barish|garmi|sardi|temperature)/i.test(lower)) {
    const cityMatch = text.match(/(?:in|of|at|ka|ki|ke)\s+([a-zA-Z\s]{2,25})(?:\s+ka|\s+mausam|\s+weather|$)/i);
    let city = cityMatch?.[1]
      ?.replace(/\b(aaj|today|ka|ki|mausam|weather|batao|bata|hai)\b/gi, '')
      .trim();
    if (!city || city.length < 2) city = 'Karachi';
    return { intent: 'weather', city };
  }

  // 5. Quick App Launch
  if (/(open|kholo|chalao|start|launch)\s+.*youtube/i.test(lower) || /\byoutube\b/i.test(lower) && /\b(kholo|open)\b/i.test(lower)) {
    return { intent: 'open_app', app: 'youtube' };
  }
  if (/(open|kholo|chalao|start)\s+.*whatsapp/i.test(lower)) {
    return { intent: 'open_app', app: 'whatsapp' };
  }
  if (/(open|kholo|chalao|start)\s+.*(camera|photo|selfie)/i.test(lower)) {
    return { intent: 'open_app', app: 'camera' };
  }
  if (/(open|kholo|chalao|start)\s+.*(maps|location|rasta)/i.test(lower)) {
    return { intent: 'open_app', app: 'maps' };
  }
  if (/(open|kholo|chalao|start)\s+.*(browser|google|chrome)/i.test(lower)) {
    return { intent: 'open_app', app: 'browser' };
  }

  // 6. System / Battery / Inverter Check
  if (
    /(battery|system\s+check|phone\s+check|device\s+status|inverter\s+check|network\s+check)/i.test(
      lower
    )
  ) {
    return { intent: 'system_check' };
  }

  // 7. Call alert test
  if (/(call\s+test|call\s+aayi|incoming\s+call)/i.test(lower)) {
    return { intent: 'simulate_call' };
  }

  // 8. Save to personal memory
  if (/^(yaad\s+rakho|save\s+memory|remember\s+that)\s+/i.test(lower)) {
    const fact = text.replace(/^(yaad\s+rakho|save\s+memory|remember\s+that)\s+/i, '').trim();
    if (fact) {
      return { intent: 'save_memory', fact };
    }
  }

  return { intent: 'chat' };
}

export function formatRemindersSummary(reminders: ReminderItem[]): string {
  const pending = reminders.filter((r) => !r.completed);
  if (pending.length === 0) {
    return 'Jani, abhi koi pending reminder nahi hai. Jab chaho bol do "Nazia kal 5 baje yaad dilana".';
  }
  const lines = pending.map((r, i) => `${i + 1}. ${r.title} (${r.dueText})`).join(' | ');
  return `Jani, aap ke ${pending.length} pending reminders hain: ${lines}`;
}

export function describeWeatherCode(code: number): string {
  if (code === 0) return 'Aasmaan bilkul saaf';
  if (code <= 3) return 'Halkay badal';
  if (code <= 48) return 'Dhund / Kohra';
  if (code <= 67) return 'Halki ya tez barish';
  if (code <= 77) return 'Barafbari';
  if (code <= 82) return 'Barish ke jhonke';
  if (code >= 95) return 'Garaj chamak ke sath toofan';
  return 'Khushgawar mausam';
}
