import { useEffect, useRef, useState, type FormEvent, type PointerEvent as ReactPointerEvent } from 'react';
import {
  Camera,
  Check,
  Copy,
  Download,
  Ear,
  Eye,
  EyeOff,
  GripHorizontal,
  Hand,
  Keyboard,
  Mic,
  MicOff,
  Monitor,
  MonitorOff,
  PhoneIncoming,
  Plus,
  Send,
  Sparkles,
  Trash2,
  Volume2,
} from 'lucide-react';
import type {
  ActiveToolModal,
  CharacterConfig,
  MemoryProfile,
  NaziaStatus,
  PanelRect,
  ReminderItem,
  VisualHubPreset,
  VisualPresetId,
} from '../types';
import { HologramCore } from './HologramCore';
import { VisualHubCanvas } from './VisualHubCanvas';

interface LiveWorkspaceProps {
  status: NaziaStatus;
  micLevel: number;
  isListening: boolean;
  interimText: string;
  latestBubbleText: string;
  awarenessOn: boolean;
  wakeWordEnabled: boolean;
  memory: MemoryProfile;
  reminders: ReminderItem[];
  notes: string[];
  character: CharacterConfig;
  inputText: string;
  onInputChange: (v: string) => void;
  onSendCommand: (text?: string, imageBase64?: string) => void;
  onToggleMic: () => void;
  onStartListening: () => void;
  onToggleAwareness: () => void;
  onSetAwareness: (val: boolean) => void;
  onToggleWakeWord: () => void;
  onUpdateMemory: (next: MemoryProfile) => void;
  onUpdateCharacter: (next: CharacterConfig) => void;
  onAddNote: (note: string) => void;
  onDeleteNote: (index: number) => void;
  onDeleteReminder: (id: string) => void;
  onSimulateCall: () => void;
  onDownloadZip: () => void;
  onOpenModal: (m: ActiveToolModal) => void;
}

type LeftPanelId = 'memory' | 'skills' | 'character' | 'setting';

const VISUAL_PRESETS: VisualHubPreset[] = [
  {
    id: 'starship',
    label: 'Draw a SpaceX Starship',
    subtitle: 'Orbital heavy-lift stainless steel blueprint',
    prompt: 'Nazia SpaceX Starship ke baray mein Urdu mein explain karo',
  },
  {
    id: 'blackhole',
    label: 'Show black hole',
    subtitle: 'Event horizon & relativistic accretion disk',
    prompt: 'Nazia Black Hole kya hota hai? Urdu mein samjhao',
  },
  {
    id: 'fusion',
    label: 'Look inside fusion reactor',
    subtitle: 'Magnetic confinement tokamak plasma core',
    prompt: 'Nazia Fusion reactor kaise kaam karta hai? Urdu mein batao',
  },
  {
    id: 'mars',
    label: 'Plan mission to Mars',
    subtitle: 'Hohmann transfer window & orbital timeline',
    prompt: 'Nazia Mars mission ka mukamal plan Urdu mein do',
  },
];

const INITIAL_RECTS: Record<LeftPanelId, PanelRect> = {
  memory: { x: 0, y: 0, w: 300, h: 200 },
  skills: { x: 0, y: 212, w: 300, h: 165 },
  character: { x: 0, y: 389, w: 300, h: 175 },
  setting: { x: 0, y: 576, w: 300, h: 155 },
};

export function LiveWorkspace({
  status,
  micLevel,
  isListening,
  interimText,
  latestBubbleText,
  awarenessOn,
  wakeWordEnabled,
  memory,
  reminders,
  notes,
  character,
  inputText,
  onInputChange,
  onSendCommand,
  onToggleMic,
  onStartListening,
  onToggleAwareness,
  onSetAwareness,
  onToggleWakeWord,
  onUpdateMemory,
  onUpdateCharacter,
  onAddNote,
  onDeleteNote,
  onDeleteReminder,
  onSimulateCall,
  onDownloadZip,
  onOpenModal,
}: LiveWorkspaceProps) {
  const [rects, setRects] = useState<Record<LeftPanelId, PanelRect>>(INITIAL_RECTS);
  const [activeVisual, setActiveVisual] = useState<VisualPresetId>('starship');
  const [newFact, setNewFact] = useState('');
  const [newNote, setNewNote] = useState('');
  const [displayEyesOn, setDisplayEyesOn] = useState(false);
  const [visionError, setVisionError] = useState<string | null>(null);
  const [typedOutput, setTypedOutput] = useState(latestBubbleText);
  const [isTypingActive, setIsTypingActive] = useState(false);
  const [copiedTyped, setCopiedTyped] = useState(false);

  const [skillsState, setSkillsState] = useState({
    urduVoice: true,
    webSearch: true,
    screenReader: true,
    callAnnouncer: true,
    tiktokPlanner: true,
  });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const lastTypedSourceRef = useRef<string>('');
  const dragRef = useRef<{
    id: LeftPanelId;
    mode: 'drag' | 'resize';
    startX: number;
    startY: number;
    orig: PanelRect;
  } | null>(null);

  // Typewriter animation synced with Nazia's Holographic Hands
  useEffect(() => {
    if (!latestBubbleText || latestBubbleText === lastTypedSourceRef.current) return;
    lastTypedSourceRef.current = latestBubbleText;
    const target = latestBubbleText;
    setTypedOutput('');
    setIsTypingActive(true);
    let idx = 0;

    const timer = window.setInterval(() => {
      idx += 2;
      if (idx >= target.length) {
        setTypedOutput(target);
        setIsTypingActive(false);
        window.clearInterval(timer);
      } else {
        setTypedOutput(target.slice(0, idx));
      }
    }, 28);

    return () => window.clearInterval(timer);
  }, [latestBubbleText]);

  // Manage live webcam Awareness feed (Camera Eyes)
  useEffect(() => {
    let cancelled = false;
    async function syncCamera() {
      if (awarenessOn) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
            audio: false,
          });
          if (cancelled) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          streamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch {
          // Camera permission declined or unavailable
        }
      } else {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((t) => t.stop());
          streamRef.current = null;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = null;
        }
      }
    }
    syncCamera();
    return () => {
      cancelled = true;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, [awarenessOn]);

  // Cleanup Display Eyes stream on unmount
  useEffect(() => {
    return () => {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((t) => t.stop());
        screenStreamRef.current = null;
      }
    };
  }, []);

  async function startDisplayEyes(): Promise<boolean> {
    setVisionError(null);
    if (!navigator.mediaDevices?.getDisplayMedia) {
      setVisionError(
        'Mobile browser par direct Display Capture blocked ho sakta hai — Camera Eyes ON kar di gayi hain.'
      );
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: false,
      });
      screenStreamRef.current = stream;
      if (screenVideoRef.current) {
        screenVideoRef.current.srcObject = stream;
      }
      setDisplayEyesOn(true);
      const track = stream.getVideoTracks()[0];
      if (track) {
        track.onended = () => {
          setDisplayEyesOn(false);
          screenStreamRef.current = null;
        };
      }
      return true;
    } catch {
      setVisionError('Display screen permission cancel hui — Camera ya Mic se jari rakhein.');
      return false;
    }
  }

  function stopDisplayEyes() {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
    }
    if (screenVideoRef.current) {
      screenVideoRef.current.srcObject = null;
    }
    setDisplayEyesOn(false);
  }

  async function handleToggleDisplayEyes() {
    if (displayEyesOn) {
      stopDisplayEyes();
    } else {
      await startDisplayEyes();
    }
  }

  // Master 1-Tap Activate All Senses: Eyes (Display + Camera) + Ears (Voice Listen) + Speak + Hands Typing
  async function handleActivateAllSenses() {
    setVisionError(null);
    onSetAwareness(true);
    if (!isListening) {
      onStartListening();
    }
    if (!displayEyesOn) {
      await startDisplayEyes();
    }
  }

  function startPointerOp(
    e: ReactPointerEvent,
    id: LeftPanelId,
    mode: 'drag' | 'resize'
  ) {
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = {
      id,
      mode,
      startX: e.clientX,
      startY: e.clientY,
      orig: { ...rects[id] },
    };
  }

  function movePointerOp(e: ReactPointerEvent) {
    const op = dragRef.current;
    if (!op) return;
    const dx = e.clientX - op.startX;
    const dy = e.clientY - op.startY;
    setRects((prev) => {
      const next = { ...prev };
      if (op.mode === 'drag') {
        next[op.id] = {
          ...op.orig,
          x: Math.max(0, Math.min(260, op.orig.x + dx)),
          y: Math.max(0, Math.min(620, op.orig.y + dy)),
        };
      } else {
        next[op.id] = {
          ...op.orig,
          w: Math.max(240, Math.min(440, op.orig.w + dx)),
          h: Math.max(130, Math.min(340, op.orig.h + dy)),
        };
      }
      return next;
    });
  }

  function endPointerOp() {
    dragRef.current = null;
  }

  function captureActiveEyeAndAsk(customPrompt?: string) {
    const targetVideo =
      displayEyesOn && screenVideoRef.current?.videoWidth
        ? screenVideoRef.current
        : awarenessOn && videoRef.current?.videoWidth
        ? videoRef.current
        : null;

    if (!targetVideo) {
      onSendCommand(
        customPrompt || inputText.trim() || 'Jani meri aankhein ON karein taake main dekh sakun.'
      );
      return;
    }

    const canvas = document.createElement('canvas');
    canvas.width = targetVideo.videoWidth;
    canvas.height = targetVideo.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(targetVideo, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
      const defaultAsk = displayEyesOn
        ? 'Nazia meri display screen dekh kar Urdu mein batao kya nazar aa raha hai aur kya karna chahiye?'
        : 'Nazia camera se mujhe dekh kar Urdu mein batao kya nazar aa raha hai?';
      onSendCommand(customPrompt || inputText.trim() || defaultAsk, dataUrl);
    }
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!inputText.trim()) return;
    if (
      (displayEyesOn || awarenessOn) &&
      /dekh|dekho|camera|look|nazar|screen|display|parho|main kaisa/i.test(inputText)
    ) {
      captureActiveEyeAndAsk(inputText);
    } else {
      onSendCommand(inputText);
    }
  }

  function handleCopyTyped() {
    if (!typedOutput) return;
    navigator.clipboard?.writeText(typedOutput).catch(() => {});
    setCopiedTyped(true);
    setTimeout(() => setCopiedTyped(false), 2000);
  }

  const eyesActive = awarenessOn || displayEyesOn;
  const earsActive = isListening || wakeWordEnabled;

  const renderPanelContent = (id: LeftPanelId) => {
    if (id === 'memory') {
      return (
        <div className="space-y-2 text-xs">
          <div className="grid grid-cols-2 gap-1.5">
            <input
              type="text"
              value={memory.work}
              onChange={(e) => onUpdateMemory({ ...memory, work: e.target.value })}
              placeholder="Work / Kaam"
              className="rounded-lg border border-slate-700 bg-slate-900/90 px-2 py-1.5 text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
            />
            <input
              type="text"
              value={memory.inverterSystem}
              onChange={(e) => onUpdateMemory({ ...memory, inverterSystem: e.target.value })}
              placeholder="Inverter / Solar"
              className="rounded-lg border border-slate-700 bg-slate-900/90 px-2 py-1.5 text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
            />
          </div>
          <div className="flex gap-1.5">
            <input
              type="text"
              value={newFact}
              onChange={(e) => setNewFact(e.target.value)}
              placeholder="Koi personal detail yaad karwayein..."
              className="flex-1 rounded-lg border border-slate-700 bg-slate-900/90 px-2 py-1.5 text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => {
                if (!newFact.trim()) return;
                onUpdateMemory({
                  ...memory,
                  customFacts: [...memory.customFacts, newFact.trim()],
                });
                setNewFact('');
              }}
              aria-label="Add memory fact"
              className="px-2.5 rounded-lg bg-cyan-600/30 border border-cyan-400/50 text-cyan-200 hover:bg-cyan-600/50 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
          {memory.customFacts.length > 0 && (
            <ul className="space-y-1 max-h-20 overflow-y-auto">
              {memory.customFacts.map((fact, idx) => (
                <li key={idx} className="flex items-center justify-between gap-2 text-slate-300">
                  <span className="truncate">{fact}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateMemory({
                        ...memory,
                        customFacts: memory.customFacts.filter((_, i) => i !== idx),
                      })
                    }
                    className="text-slate-500 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      );
    }

    if (id === 'skills') {
      const items: Array<[keyof typeof skillsState, string]> = [
        ['urduVoice', 'Urdu Female Voice'],
        ['webSearch', 'Internet AI Search'],
        ['screenReader', 'Screen & Link Reader'],
        ['callAnnouncer', 'Call Alert ("Jani call aayi")'],
        ['tiktokPlanner', 'TikTok & Earning Planner'],
      ];
      return (
        <div className="space-y-1.5 text-xs">
          {items.map(([key, label]) => (
            <label key={key} className="flex items-center justify-between gap-2 cursor-pointer py-0.5">
              <span className="text-slate-200">{label}</span>
              <input
                type="checkbox"
                checked={skillsState[key]}
                onChange={() =>
                  setSkillsState((prev) => ({ ...prev, [key]: !prev[key] }))
                }
                className="accent-cyan-400 w-4 h-4 cursor-pointer"
              />
            </label>
          ))}
        </div>
      );
    }

    if (id === 'character') {
      return (
        <div className="space-y-2 text-xs">
          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Language</span>
              <span className="text-cyan-300">{character.language}</span>
            </div>
            <div className="grid grid-cols-3 gap-1">
              {(['roman-urdu', 'urdu-script', 'english'] as const).map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => onUpdateCharacter({ ...character, language: lang })}
                  className={`py-1 rounded-md border text-[11px] cursor-pointer ${
                    character.language === lang
                      ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                      : 'border-slate-700 text-slate-400'
                  }`}
                >
                  {lang === 'roman-urdu' ? 'Roman' : lang === 'urdu-script' ? 'اردو' : 'EN'}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div className="flex justify-between text-slate-300">
              <span>Voice Pitch</span>
              <span className="tabular-nums text-cyan-300">{character.voicePitch.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.4"
              step="0.02"
              value={character.voicePitch}
              onChange={(e) =>
                onUpdateCharacter({ ...character, voicePitch: Number(e.target.value) })
              }
              className="w-full accent-cyan-400"
            />
          </div>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-2 gap-2 text-xs">
        <button
          type="button"
          onClick={onToggleWakeWord}
          className={`col-span-2 min-h-[36px] rounded-lg border px-2 font-medium cursor-pointer ${
            wakeWordEnabled
              ? 'border-emerald-400/70 bg-emerald-500/15 text-emerald-200'
              : 'border-slate-700 text-slate-300'
          }`}
        >
          Wake &quot;Nazia&quot;: {wakeWordEnabled ? 'ON' : 'OFF'}
        </button>
        <button
          type="button"
          onClick={onDownloadZip}
          className="col-span-2 min-h-[36px] rounded-lg border border-cyan-500/50 bg-cyan-500/15 text-cyan-200 flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          Download Full Source ZIP
        </button>
      </div>
    );
  };

  return (
    <div className="w-full max-w-[1400px] mx-auto px-3 sm:px-6 pb-8 space-y-5">
      {/* Top Senses Control Bar: Display Eyes + Camera Eyes + Ears + Voice + Typing Hands */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-cyan-500/30 bg-slate-950/85 px-4 py-3">
        <div>
          <span className="font-display text-sm font-semibold text-white">
            LIVE HOLOGRAM DISPLAY
          </span>
          <p className="text-xs text-slate-400 mt-0.5">
            Aankhein (Display &amp; Camera) · Kaan (Sunna) · Bolna · Hath se Typing
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleActivateAllSenses}
            className="min-h-[42px] px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-600 text-slate-950 text-xs font-bold flex items-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(16,185,129,0.35)]"
          >
            <Sparkles className="w-4 h-4" />
            <span>On Display Senses (All ON)</span>
          </button>

          <button
            type="button"
            onClick={handleToggleDisplayEyes}
            className={`min-h-[42px] px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              displayEyesOn
                ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200'
                : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-cyan-400/60'
            }`}
          >
            {displayEyesOn ? <Monitor className="w-4 h-4" /> : <MonitorOff className="w-4 h-4" />}
            <span>Display Eyes: {displayEyesOn ? 'ON' : 'OFF'}</span>
          </button>

          <button
            type="button"
            onClick={onToggleAwareness}
            className={`min-h-[42px] px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              awarenessOn
                ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200'
                : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-cyan-400/60'
            }`}
          >
            {awarenessOn ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            <span>Camera Eyes: {awarenessOn ? 'ON' : 'OFF'}</span>
          </button>

          <button
            type="button"
            onClick={onSimulateCall}
            className="min-h-[42px] px-3.5 rounded-xl border border-violet-500/50 bg-violet-500/15 text-xs font-semibold text-violet-200 hover:bg-violet-500/25 flex items-center gap-1.5 cursor-pointer"
          >
            <PhoneIncoming className="w-4 h-4" />
            <span>Call Alert</span>
          </button>
        </div>
      </div>

      {/* Main 3-Zone Live Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Zone: 4 Draggable & Resizable Panels */}
        <div className="lg:col-span-4 order-2 lg:order-1">
          <div className="hidden lg:block relative h-[780px] rounded-3xl border border-slate-800/80 bg-slate-950/50 overflow-hidden p-2">
            {(['memory', 'skills', 'character', 'setting'] as LeftPanelId[]).map((id) => {
              const rect = rects[id];
              return (
                <div
                  key={id}
                  style={{
                    transform: `translate(${rect.x}px, ${rect.y}px)`,
                    width: `${rect.w}px`,
                    height: `${rect.h}px`,
                  }}
                  className="absolute top-2 left-2 rounded-2xl border border-cyan-500/35 bg-slate-950/95 shadow-lg flex flex-col overflow-hidden"
                >
                  <div
                    onPointerDown={(e) => startPointerOp(e, id, 'drag')}
                    onPointerMove={movePointerOp}
                    onPointerUp={endPointerOp}
                    className="px-3 py-2 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between cursor-grab active:cursor-grabbing select-none"
                  >
                    <span className="font-display text-xs font-bold tracking-wider uppercase text-cyan-300">
                      {id}
                    </span>
                    <GripHorizontal className="w-4 h-4 text-slate-500" />
                  </div>
                  <div className="p-3 flex-1 overflow-y-auto">{renderPanelContent(id)}</div>
                  <div
                    onPointerDown={(e) => startPointerOp(e, id, 'resize')}
                    onPointerMove={movePointerOp}
                    onPointerUp={endPointerOp}
                    title="Drag to resize"
                    className="h-3 w-full cursor-ns-resize bg-slate-900/60 hover:bg-cyan-500/20 flex items-center justify-center"
                  >
                    <span className="w-8 h-0.5 rounded-full bg-slate-600" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Mobile responsive stacked panels */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 lg:hidden">
            {(['memory', 'skills', 'character', 'setting'] as LeftPanelId[]).map((id) => (
              <div
                key={id}
                className="rounded-2xl border border-cyan-500/35 bg-slate-950/90 p-3.5"
              >
                <h3 className="font-display text-xs font-bold tracking-wider uppercase text-cyan-300 mb-2">
                  {id}
                </h3>
                {renderPanelContent(id)}
              </div>
            ))}
          </div>
        </div>

        {/* Center Zone: Full-Anatomy Hologram (Eyes + Ears + Hands + Keyboard) + Vision + Typing Pad */}
        <div className="lg:col-span-5 order-1 lg:order-2 flex flex-col items-center gap-4 rounded-3xl border border-cyan-500/35 bg-gradient-to-b from-slate-900/80 via-[#060c22]/90 to-slate-950/95 p-5 shadow-[0_0_45px_rgba(6,182,212,0.16)]">
          {/* Active Sensory Indicator Line (Unboxed clean metadata) */}
          <div className="w-full flex flex-wrap items-center justify-center gap-3 text-xs text-slate-300">
            <span className={`flex items-center gap-1 ${eyesActive ? 'text-emerald-300 font-semibold' : 'text-slate-400'}`}>
              <Eye className="w-3.5 h-3.5" />
              Aankhein {eyesActive ? 'ON' : 'Ready'}
            </span>
            <span aria-hidden="true">·</span>
            <span className={`flex items-center gap-1 ${earsActive ? 'text-emerald-300 font-semibold' : 'text-slate-400'}`}>
              <Ear className="w-3.5 h-3.5" />
              Kaan {earsActive ? 'Sun rahi' : 'Ready'}
            </span>
            <span aria-hidden="true">·</span>
            <span className={`flex items-center gap-1 ${status === 'speaking' ? 'text-cyan-300 font-semibold' : 'text-slate-400'}`}>
              <Volume2 className="w-3.5 h-3.5" />
              Boly
            </span>
            <span aria-hidden="true">·</span>
            <span className={`flex items-center gap-1 ${isTypingActive ? 'text-cyan-300 font-semibold' : 'text-slate-400'}`}>
              <Hand className="w-3.5 h-3.5" />
              Hath {isTypingActive ? 'Typing' : 'Ready'}
            </span>
          </div>

          <HologramCore
            status={status}
            mode="live"
            micLevel={micLevel}
            size="lg"
            showWaveform={true}
            showAnatomy={true}
            eyesActive={eyesActive}
            earsActive={earsActive}
            typingActive={isTypingActive}
            onTap={onToggleMic}
          />

          {/* Live Display Vision & Camera Eyes Previews */}
          {(displayEyesOn || awarenessOn) && (
            <div className="w-full space-y-2.5">
              {displayEyesOn && (
                <div className="w-full rounded-2xl border border-cyan-400/55 bg-slate-950 p-2.5 flex items-center gap-3">
                  <video
                    ref={screenVideoRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-28 h-20 rounded-xl object-cover bg-slate-900 border border-slate-800"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-cyan-300">
                      Nazia Display Eyes Active
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Nazia aap ki display screen dekh rahi hai.
                    </p>
                    <button
                      type="button"
                      onClick={() => captureActiveEyeAndAsk()}
                      className="mt-1.5 min-h-[34px] px-3 rounded-lg bg-cyan-500/20 border border-cyan-400/60 text-[11px] font-semibold text-cyan-100 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Monitor className="w-3.5 h-3.5" />
                      <span>Nazia Display Dekho &amp; Bolo</span>
                    </button>
                  </div>
                </div>
              )}

              {awarenessOn && (
                <div className="w-full rounded-2xl border border-emerald-400/50 bg-slate-950 p-2.5 flex items-center gap-3">
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-28 h-20 rounded-xl object-cover bg-slate-900 border border-slate-800"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-emerald-300">
                      Nazia Camera Eyes Active
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Nazia camera se aap ko dekh rahi hai.
                    </p>
                    <button
                      type="button"
                      onClick={() => captureActiveEyeAndAsk()}
                      className="mt-1.5 min-h-[34px] px-3 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-[11px] font-semibold text-emerald-200 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Nazia Camera Dekho</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {visionError && (
            <div className="w-full rounded-xl border border-amber-500/40 bg-amber-950/35 px-3 py-2 text-xs text-amber-200">
              {visionError}
            </div>
          )}

          {/* Live Holographic Hands Typing Pad (Nazia Typing Output Console) */}
          <div className="w-full rounded-2xl border border-cyan-400/45 bg-slate-950/90 p-3.5 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-cyan-300">
                <Keyboard className="w-4 h-4" />
                <span>
                  {isTypingActive
                    ? 'Nazia Hath se Type kar rahi hai...'
                    : 'Nazia Typing Output Console'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleCopyTyped}
                  className="min-h-[30px] px-2.5 rounded-lg border border-slate-700 bg-slate-900 text-[11px] text-slate-200 hover:border-cyan-400 flex items-center gap-1 cursor-pointer"
                >
                  {copiedTyped ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedTyped ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (typedOutput.trim()) onAddNote(typedOutput.trim());
                  }}
                  className="min-h-[30px] px-2.5 rounded-lg border border-violet-500/40 bg-violet-500/15 text-[11px] text-violet-200 cursor-pointer"
                >
                  Save Note
                </button>
              </div>
            </div>

            <div className="min-h-[68px] rounded-xl border border-slate-800 bg-slate-900/90 p-3 text-sm text-cyan-100 leading-relaxed font-sans">
              {interimText ? (
                <span className="text-emerald-300">Sun rahi hoon: &quot;{interimText}&quot;</span>
              ) : (
                <span>
                  {typedOutput}
                  {isTypingActive && (
                    <span className="inline-block w-2 h-4 ml-0.5 bg-cyan-400 align-middle animate-pulse" />
                  )}
                </span>
              )}
            </div>

            {/* Quick Hands Typing Prompts */}
            <div className="flex flex-wrap gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() =>
                  onSendCommand('Jani ke liye ek pyara Urdu WhatsApp message type karo')
                }
                className="min-h-[30px] px-2.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Type WhatsApp Msg
              </button>
              <button
                type="button"
                onClick={() =>
                  onSendCommand('Jani ke liye ek viral TikTok caption Urdu mein type karo')
                }
                className="min-h-[30px] px-2.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Type TikTok Caption
              </button>
              <button
                type="button"
                onClick={() => captureActiveEyeAndAsk('Meri display dekh kar summary type karo')}
                className="min-h-[30px] px-2.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Dekho &amp; Type Summary
              </button>
            </div>
          </div>

          {/* Voice + Input Controls */}
          <form onSubmit={handleSubmit} className="w-full flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleMic}
              aria-label={isListening ? 'Stop mic' : 'Start mic'}
              className={`min-w-[48px] min-h-[48px] rounded-full border flex items-center justify-center cursor-pointer transition-all ${
                isListening
                  ? 'border-emerald-400 bg-emerald-500/25 text-emerald-200'
                  : 'border-cyan-400/60 bg-slate-900 text-cyan-300'
              }`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => onInputChange(e.target.value)}
              placeholder="Bolein ya likhein: 'Nazia screen dekho aur type karo'..."
              className="flex-1 min-h-[48px] rounded-full border border-violet-500/50 bg-slate-950 px-4 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-400"
            />

            <button
              type="submit"
              aria-label="Send message"
              className="min-w-[48px] min-h-[48px] rounded-full bg-gradient-to-r from-cyan-500 to-violet-600 text-white flex items-center justify-center cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Right Zone: VOICE & NOTES Panels */}
        <div className="lg:col-span-3 order-3 flex flex-col gap-4">
          <div className="rounded-2xl border border-cyan-500/35 bg-slate-950/90 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-xs font-bold tracking-wider uppercase text-cyan-300">
                VOICE &amp; EARS
              </h3>
              <Volume2 className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Wake Word: <strong className="text-white">&quot;Nazia&quot;</strong> bolne par
              jawab milega <strong className="text-cyan-300">&quot;Ji Jani bolo&quot;</strong>.
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={onToggleMic}
                className="min-h-[40px] rounded-xl border border-emerald-400/60 bg-emerald-500/15 text-xs font-medium text-emerald-200 cursor-pointer"
              >
                {isListening ? 'Stop Voice' : 'Start Voice'}
              </button>
              <button
                type="button"
                onClick={() => onOpenModal('screen-assist')}
                className="min-h-[40px] rounded-xl border border-cyan-500/50 bg-cyan-500/15 text-xs font-medium text-cyan-200 cursor-pointer"
              >
                Screen / Link
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-violet-500/35 bg-slate-950/90 p-4 space-y-3">
            <h3 className="font-display text-xs font-bold tracking-wider uppercase text-violet-300">
              NOTES &amp; REMINDERS ({reminders.filter((r) => !r.completed).length})
            </h3>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="TikTok / kaam ka note..."
                className="flex-1 min-h-[38px] rounded-lg border border-slate-700 bg-slate-900 px-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-400"
              />
              <button
                type="button"
                onClick={() => {
                  if (!newNote.trim()) return;
                  onAddNote(newNote.trim());
                  setNewNote('');
                }}
                aria-label="Save note"
                className="min-w-[38px] min-h-[38px] rounded-lg bg-violet-600/35 border border-violet-400/50 text-violet-100 flex items-center justify-center cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {notes.map((n, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between gap-2 rounded-lg bg-slate-900/90 border border-slate-800 px-2.5 py-1.5 text-xs text-slate-200"
                >
                  <span className="truncate">{n}</span>
                  <button
                    type="button"
                    onClick={() => onDeleteNote(idx)}
                    className="text-slate-500 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              {reminders
                .filter((r) => !r.completed)
                .map((r) => (
                  <div
                    key={r.id}
                    className="flex items-center justify-between gap-2 rounded-lg bg-cyan-950/35 border border-cyan-500/25 px-2.5 py-1.5 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="text-cyan-100 truncate">{r.title}</p>
                      <p className="text-[11px] text-cyan-400 tabular-nums">{r.dueText}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onDeleteReminder(r.id)}
                      className="text-slate-400 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom VISUAL HUB Ready */}
      <section className="rounded-3xl border border-cyan-500/35 bg-slate-950/90 p-4 sm:p-5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
          <div className="lg:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="font-display text-sm font-bold tracking-wider uppercase text-cyan-300">
                VISUAL HUB Ready
              </span>
            </div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-white">
              What do you want to see?
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {VISUAL_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setActiveVisual(preset.id);
                    onSendCommand(preset.prompt);
                  }}
                  className={`min-h-[46px] rounded-xl border px-3 py-2 text-left transition-all cursor-pointer ${
                    activeVisual === preset.id
                      ? 'border-cyan-400 bg-cyan-500/20 text-white shadow-[0_0_16px_rgba(34,211,238,0.25)]'
                      : 'border-slate-800 bg-slate-900/90 text-slate-300 hover:border-cyan-500/50'
                  }`}
                >
                  <p className="text-xs font-semibold">{preset.label}</p>
                  <p className="text-[11px] text-slate-400 truncate">{preset.subtitle}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7">
            <VisualHubCanvas preset={activeVisual} />
          </div>
        </div>
      </section>
    </div>
  );
}
