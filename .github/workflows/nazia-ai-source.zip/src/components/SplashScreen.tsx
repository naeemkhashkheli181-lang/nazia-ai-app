import { useEffect, useState } from 'react';
import { Brain, Crown } from 'lucide-react';
import { HologramCore } from './HologramCore';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(12);

  useEffect(() => {
    const start = Date.now();
    const duration = 1200;
    const timer = setInterval(() => {
      const elapsed = Date.now() - start;
      const pct = Math.min(100, Math.round(20 + (elapsed / duration) * 80));
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(timer);
        setTimeout(onComplete, 140);
      }
    }, 45);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="relative min-h-dvh w-full overflow-hidden bg-[#020617] flex flex-col items-center justify-between px-6 py-8 text-center">
      {/* Neon atmospheric background */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_28%,rgba(6,182,212,0.22),rgba(139,92,246,0.12)_42%,transparent_72%)]" />

      {/* Futuristic horizon skyline + circuit floor */}
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-44 opacity-35"
        aria-hidden="true"
      >
        <svg viewBox="0 0 800 180" className="w-full h-full preserve-3d" preserveAspectRatio="none">
          <defs>
            <linearGradient id="skylineGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#020617" stopOpacity="0.95" />
            </linearGradient>
          </defs>
          <path
            d="M0,180 L0,115 L35,115 L35,70 L65,70 L65,120 L105,120 L105,45 L140,45 L140,125 L195,125 L195,85 L235,85 L235,140 L565,140 L565,80 L605,80 L605,125 L660,125 L660,40 L700,40 L700,115 L745,115 L745,68 L780,68 L780,120 L800,120 L800,180 Z"
            fill="url(#skylineGrad)"
          />
          <line x1="0" y1="150" x2="800" y2="150" stroke="#22d3ee" strokeOpacity="0.45" strokeWidth="1" />
          <line x1="100" y1="165" x2="700" y2="165" stroke="#a855f7" strokeOpacity="0.45" strokeWidth="1" />
        </svg>
      </div>

      {/* Top spacer */}
      <div className="relative z-10 w-full max-w-md flex justify-end">
        <button
          type="button"
          onClick={onComplete}
          className="min-h-[44px] px-3 text-xs font-medium text-cyan-300/80 hover:text-cyan-200 transition-colors cursor-pointer"
        >
          Skip
        </button>
      </div>

      {/* Center Hologram & Brand Lockup */}
      <div className="relative z-10 flex flex-col items-center max-w-md w-full my-auto">
        <HologramCore status="thinking" mode="classic" micLevel={0} size="lg" showWaveform={false} />

        {/* Golden Crown + Title */}
        <div className="mt-3 flex flex-col items-center">
          <Crown className="w-10 h-10 text-amber-400 drop-shadow-[0_0_16px_rgba(251,191,36,0.65)] mb-1" />
          <h1 className="font-display text-5xl sm:text-6xl font-bold tracking-tight bg-gradient-to-r from-white via-cyan-200 to-violet-300 bg-clip-text text-transparent">
            Nazia AI
          </h1>
          <p className="mt-1.5 text-xs sm:text-sm font-semibold tracking-[0.18em] text-slate-200">
            YOUR SMART PERSONAL ASSISTANT
          </p>
          <div className="mt-3 px-5 py-2 rounded-full border border-cyan-400/45 bg-slate-900/75 backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.2)]">
            <span className="text-xs sm:text-sm font-medium text-cyan-200">
              Think · Speak · Get Help
            </span>
          </div>
        </div>

        {/* Glowing Brain Hologram */}
        <div className="mt-6 relative flex items-center justify-center w-20 h-20 rounded-full border border-cyan-400/60 bg-cyan-950/35 shadow-[0_0_32px_rgba(34,211,238,0.45)]">
          <div className="absolute inset-1.5 rounded-full border border-violet-400/40" />
          <Brain className="w-10 h-10 text-cyan-300 drop-shadow-[0_0_12px_rgba(34,211,238,0.8)]" />
        </div>
      </div>

      {/* Bottom Loading Bar */}
      <div className="relative z-10 w-full max-w-sm flex flex-col items-center gap-2.5">
        <div className="w-full h-3 rounded-full bg-slate-900/90 border border-violet-500/45 overflow-hidden p-0.5 shadow-[0_0_18px_rgba(139,92,246,0.25)]">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-violet-500 transition-all duration-100"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-xs font-medium text-slate-200 tabular-nums">
          Initializing Nazia AI... {progress}%
        </p>
        <div className="w-full py-2 border-t border-cyan-500/20 text-[11px] text-slate-400 tracking-wide">
          Powered by Intelligence
        </div>
      </div>
    </div>
  );
}
