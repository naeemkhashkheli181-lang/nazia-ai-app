import { useEffect, useRef, useState, type ChangeEvent } from 'react';
import {
  BatteryCharging,
  BellRing,
  Camera,
  CheckCircle2,
  Download,
  ExternalLink,
  HardDrive,
  Link2,
  Monitor,
  PhoneIncoming,
  Plus,
  Send,
  Smartphone,
  Trash2,
  Upload,
  Volume2,
  Wifi,
  X,
} from 'lucide-react';
import type {
  ActiveToolModal,
  CharacterConfig,
  ChatMessage,
  MemoryProfile,
  ReminderItem,
} from '../types';

interface ToolModalsProps {
  modal: ActiveToolModal;
  messages: ChatMessage[];
  reminders: ReminderItem[];
  memory: MemoryProfile;
  character: CharacterConfig;
  wakeWordEnabled: boolean;
  onClose: () => void;
  onSendCommand: (text: string, mode?: 'chat' | 'search' | 'code' | 'screen', imageBase64?: string) => void;
  onAddReminder: (title: string, dueText: string) => void;
  onDeleteReminder: (id: string) => void;
  onToggleReminder: (id: string) => void;
  onUpdateMemory: (next: MemoryProfile) => void;
  onUpdateCharacter: (next: CharacterConfig) => void;
  onToggleWakeWord: () => void;
  onSpeakText: (text: string) => void;
  onSimulateCall: () => void;
  onDownloadZip: () => void;
  canInstallPwa: boolean;
  onInstallPwa: () => void;
}

interface BatteryInfo {
  level: number;
  charging: boolean;
}

export function ToolModals({
  modal,
  messages,
  reminders,
  memory,
  character,
  wakeWordEnabled,
  onClose,
  onSendCommand,
  onAddReminder,
  onDeleteReminder,
  onToggleReminder,
  onUpdateMemory,
  onUpdateCharacter,
  onToggleWakeWord,
  onSpeakText,
  onSimulateCall,
  onDownloadZip,
  canInstallPwa,
  onInstallPwa,
}: ToolModalsProps) {
  const [chatDraft, setChatDraft] = useState('');
  const [remTitle, setRemTitle] = useState('');
  const [remTime, setRemTime] = useState('Kal 5:00 PM');
  const [linkOrCode, setLinkOrCode] = useState('');
  const [screenPreview, setScreenPreview] = useState<string | null>(null);
  const [screenQuestion, setScreenQuestion] = useState('Is screen ya link ko parh kar Urdu mein masla aur solution batao');
  const [battery, setBattery] = useState<BatteryInfo | null>(null);
  const [netInfo, setNetInfo] = useState<string>('Checking...');
  const [cameraError, setCameraError] = useState<string | null>(null);

  const camVideoRef = useRef<HTMLVideoElement | null>(null);
  const camStreamRef = useRef<MediaStream | null>(null);

  // Device diagnostics for Phone Control modal
  useEffect(() => {
    if (modal !== 'phone-control') return;
    const nav = navigator as unknown as {
      getBattery?: () => Promise<{ level: number; charging: boolean }>;
      connection?: { effectiveType?: string; downlink?: number };
    };
    if (nav.getBattery) {
      nav.getBattery().then((b) => {
        setBattery({ level: Math.round(b.level * 100), charging: b.charging });
      }).catch(() => {});
    }
    if (nav.connection) {
      setNetInfo(
        `${(nav.connection.effectiveType || 'wifi').toUpperCase()} · ${nav.connection.downlink ?? '--'} Mbps`
      );
    } else {
      setNetInfo(navigator.onLine ? 'Online' : 'Offline');
    }
  }, [modal]);

  // Camera stream for Camera modal
  useEffect(() => {
    if (modal !== 'camera') {
      if (camStreamRef.current) {
        camStreamRef.current.getTracks().forEach((t) => t.stop());
        camStreamRef.current = null;
      }
      return;
    }

    let cancelled = false;
    setCameraError(null);
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: 'environment' }, audio: false })
      .then((stream) => {
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        camStreamRef.current = stream;
        if (camVideoRef.current) camVideoRef.current.srcObject = stream;
      })
      .catch(() => {
        setCameraError('Camera access allow karein taake Nazia dekh sake.');
      });

    return () => {
      cancelled = true;
      if (camStreamRef.current) {
        camStreamRef.current.getTracks().forEach((t) => t.stop());
        camStreamRef.current = null;
      }
    };
  }, [modal]);

  if (!modal) return null;

  async function handleCaptureScreen() {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const track = stream.getVideoTracks()[0];
      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
      setScreenPreview(dataUrl);
      track.stop();
    } catch {
      // User canceled screen share or unsupported on mobile browser — upload fallback works everywhere
    }
  }

  function handleImageUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setScreenPreview(reader.result);
    };
    reader.readAsDataURL(file);
  }

  function handleSnapCamera() {
    const video = camVideoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d')?.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    onSendCommand('Nazia is photo ko dekh kar Urdu mein batao kya hai aur koi masla to nahi?', 'screen', dataUrl);
    onClose();
  }

  const modalTitle =
    modal === 'chat'
      ? 'Chat with Nazia'
      : modal === 'reminders'
      ? 'Smart Reminders & Tasks'
      : modal === 'screen-assist'
      ? 'Screen Assist & Link / Code Inspector'
      : modal === 'phone-control'
      ? 'Phone Control & System Diagnostics'
      : modal === 'camera'
      ? 'Camera Awareness'
      : 'Settings, Memory & Source Export';

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={modalTitle}
    >
      <div className="w-full sm:max-w-2xl max-h-[90dvh] rounded-t-3xl sm:rounded-3xl border border-cyan-500/40 bg-slate-950 shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/70">
          <h2 className="font-display text-lg font-bold text-white">{modalTitle}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close panel"
            className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {modal === 'chat' && (
            <>
              <div className="space-y-3 max-h-[52dvh] overflow-y-auto pr-1">
                {messages.map((m) => (
                  <div
                    key={m.id}
                    className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[88%] rounded-2xl px-4 py-2.5 text-sm ${
                        m.role === 'user'
                          ? 'bg-violet-600/30 border border-violet-400/40 text-white'
                          : 'bg-slate-900 border border-cyan-500/30 text-slate-100'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{m.text}</p>
                      {m.role === 'nazia' && (
                        <button
                          type="button"
                          onClick={() => onSpeakText(m.text)}
                          className="mt-1.5 text-[11px] text-cyan-300 flex items-center gap-1 hover:text-cyan-200 cursor-pointer"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Suno</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!chatDraft.trim()) return;
                  onSendCommand(chatDraft, 'chat');
                  setChatDraft('');
                }}
                className="flex gap-2 pt-2 border-t border-slate-800"
              >
                <input
                  type="text"
                  value={chatDraft}
                  onChange={(e) => setChatDraft(e.target.value)}
                  placeholder="Jani apna sawal, link ya TikTok plan poochein..."
                  className="flex-1 min-h-[46px] rounded-xl border border-slate-700 bg-slate-900 px-3.5 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="min-w-[46px] min-h-[46px] rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 text-white flex items-center justify-center cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          )}

          {modal === 'reminders' && (
            <>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!remTitle.trim()) return;
                  onAddReminder(remTitle.trim(), remTime.trim() || 'Aaj');
                  setRemTitle('');
                }}
                className="grid grid-cols-1 sm:grid-cols-12 gap-2"
              >
                <input
                  type="text"
                  value={remTitle}
                  onChange={(e) => setRemTitle(e.target.value)}
                  placeholder="Kaam likhein (e.g. Inverter check karna)"
                  className="sm:col-span-6 min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />
                <input
                  type="text"
                  value={remTime}
                  onChange={(e) => setRemTime(e.target.value)}
                  placeholder="Waqt (e.g. Kal 5 baje)"
                  className="sm:col-span-4 min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="sm:col-span-2 min-h-[44px] rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add</span>
                </button>
              </form>

              <div className="flex items-center justify-between pt-1">
                <span className="text-xs text-slate-400">
                  Tip: Voice mein bolein &quot;Nazia kal 5 baje yaad dilana&quot; ya &quot;Nazia mujhe yaad dilao&quot;
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const pending = reminders.filter((r) => !r.completed);
                    onSpeakText(
                      pending.length
                        ? `Jani aap ke ${pending.length} pending reminders hain: ${pending
                            .map((r) => `${r.title} ${r.dueText}`)
                            .join(', ')}`
                        : 'Jani abhi koi pending reminder nahi hai.'
                    );
                  }}
                  className="min-h-[36px] px-3 rounded-lg border border-cyan-500/40 text-xs text-cyan-300 flex items-center gap-1.5 cursor-pointer"
                >
                  <BellRing className="w-3.5 h-3.5" />
                  <span>Read List</span>
                </button>
              </div>

              <ul className="divide-y divide-slate-800">
                {reminders.length === 0 && (
                  <li className="py-6 text-center text-sm text-slate-400">
                    Koi reminder save nahi hai.
                  </li>
                )}
                {reminders.map((r) => (
                  <li key={r.id} className="py-3 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => onToggleReminder(r.id)}
                      className="flex items-center gap-3 flex-1 text-left cursor-pointer"
                    >
                      <CheckCircle2
                        className={`w-5 h-5 shrink-0 ${
                          r.completed ? 'text-emerald-400' : 'text-slate-600'
                        }`}
                      />
                      <div>
                        <p
                          className={`text-sm font-medium ${
                            r.completed ? 'line-through text-slate-500' : 'text-white'
                          }`}
                        >
                          {r.title}
                        </p>
                        <p className="text-xs text-cyan-300 tabular-nums">{r.dueText}</p>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteReminder(r.id)}
                      className="min-w-[40px] min-h-[40px] rounded-lg flex items-center justify-center text-slate-400 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}

          {modal === 'screen-assist' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleCaptureScreen}
                  className="min-h-[48px] rounded-xl border border-cyan-500/50 bg-cyan-500/15 text-sm font-semibold text-cyan-200 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Monitor className="w-4 h-4" />
                  <span>Capture Live Screen</span>
                </button>

                <label className="min-h-[48px] rounded-xl border border-violet-500/50 bg-violet-500/15 text-sm font-semibold text-violet-200 flex items-center justify-center gap-2 cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>Upload Screenshot / Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="sr-only"
                  />
                </label>
              </div>

              {screenPreview && (
                <img
                  src={screenPreview}
                  alt="Captured screen preview"
                  className="w-full max-h-48 object-contain rounded-2xl border border-cyan-500/40 bg-slate-900"
                />
              )}

              <div>
                <label className="block text-xs font-medium text-cyan-300 mb-1.5">
                  Website Link (URL) ya Code Paste Karein
                </label>
                <textarea
                  rows={3}
                  value={linkOrCode}
                  onChange={(e) => setLinkOrCode(e.target.value)}
                  placeholder="https://example.com ya apna code yahan paste karein..."
                  className="w-full rounded-xl border border-slate-700 bg-slate-900 p-3 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-cyan-300 mb-1.5">
                  Nazia se kya poochna hai?
                </label>
                <input
                  type="text"
                  value={screenQuestion}
                  onChange={(e) => setScreenQuestion(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  const combined = [screenQuestion, linkOrCode].filter(Boolean).join('\n\n');
                  onSendCommand(combined, 'screen', screenPreview || undefined);
                  onClose();
                }}
                className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer"
              >
                <Link2 className="w-4 h-4" />
                <span>Analyze Screen / Link Now</span>
              </button>
            </div>
          )}

          {modal === 'phone-control' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-3.5">
                  <div className="flex items-center gap-2 text-emerald-300 text-xs mb-1">
                    <BatteryCharging className="w-4 h-4" />
                    <span>Battery</span>
                  </div>
                  <p className="text-lg font-bold text-white tabular-nums">
                    {battery ? `${battery.level}%` : 'Browser Protected'}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    {battery ? (battery.charging ? 'Charging' : 'On Battery') : 'Check phone bar'}
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-3.5">
                  <div className="flex items-center gap-2 text-cyan-300 text-xs mb-1">
                    <Wifi className="w-4 h-4" />
                    <span>Network</span>
                  </div>
                  <p className="text-sm font-bold text-white">{netInfo}</p>
                  <p className="text-[11px] text-slate-400">
                    {navigator.onLine ? 'Connected' : 'Offline'}
                  </p>
                </div>

                <div className="col-span-2 sm:col-span-1 rounded-2xl border border-slate-800 bg-slate-900/80 p-3.5">
                  <div className="flex items-center gap-2 text-violet-300 text-xs mb-1">
                    <HardDrive className="w-4 h-4" />
                    <span>Inverter / System</span>
                  </div>
                  <p className="text-xs font-semibold text-white truncate">
                    {memory.inverterSystem || 'Not set in Memory'}
                  </p>
                  <p className="text-[11px] text-slate-400 truncate">
                    {memory.deviceSetup || `${window.screen.width}x${window.screen.height} display`}
                  </p>
                </div>
              </div>

              <div className="rounded-2xl border border-violet-500/35 bg-violet-950/20 p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-white">
                    Call Alert &amp; Speaker Assistant
                  </h3>
                  <p className="text-xs text-slate-300">
                    Nazia call aane par awaz de gi: &quot;Jani call aayi hai!&quot;
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onSimulateCall();
                    onClose();
                  }}
                  className="min-h-[42px] px-4 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
                >
                  <PhoneIncoming className="w-4 h-4" />
                  <span>Test Call Alert</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { name: 'YouTube', url: 'https://www.youtube.com' },
                  { name: 'WhatsApp', url: 'https://wa.me/' },
                  { name: 'Google', url: 'https://www.google.com' },
                  { name: 'Maps', url: 'https://maps.google.com' },
                ].map((app) => (
                  <a
                    key={app.name}
                    href={app.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 flex items-center justify-between text-xs font-medium text-slate-200 hover:border-cyan-400"
                  >
                    <span>Open {app.name}</span>
                    <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
                  </a>
                ))}
              </div>
            </div>
          )}

          {modal === 'camera' && (
            <div className="space-y-4">
              {cameraError ? (
                <div className="rounded-2xl border border-rose-500/40 bg-rose-950/30 p-4 text-sm text-rose-200">
                  {cameraError}
                </div>
              ) : (
                <video
                  ref={camVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-64 sm:h-80 object-cover rounded-2xl border border-cyan-500/40 bg-slate-900"
                />
              )}
              <button
                type="button"
                onClick={handleSnapCamera}
                disabled={Boolean(cameraError)}
                className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Camera className="w-4 h-4" />
                <span>Photo Kheench Kar Nazia Se Poocho</span>
              </button>
            </div>
          )}

          {(modal === 'settings' || modal === 'menu') && (
            <div className="space-y-5">
              {/* Personal Memory Vault */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                <h3 className="font-display text-sm font-bold text-cyan-300">
                  Jani Personal Memory (Sirf jo aap batayein)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    value={memory.work}
                    onChange={(e) => onUpdateMemory({ ...memory, work: e.target.value })}
                    placeholder="Mera Kaam (Work)"
                    className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={memory.accounts}
                    onChange={(e) => onUpdateMemory({ ...memory, accounts: e.target.value })}
                    placeholder="Accounts ke naam"
                    className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={memory.inverterSystem}
                    onChange={(e) =>
                      onUpdateMemory({ ...memory, inverterSystem: e.target.value })
                    }
                    placeholder="Mera Inverter / Solar setup"
                    className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={memory.deviceSetup}
                    onChange={(e) => onUpdateMemory({ ...memory, deviceSetup: e.target.value })}
                    placeholder="Mera Phone / System model"
                    className="min-h-[42px] rounded-xl border border-slate-700 bg-slate-950 px-3 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Voice & Wake Word */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-white">Wake Word: &quot;Nazia&quot;</p>
                    <p className="text-xs text-slate-400">
                      &quot;Nazia&quot; kehne par jawab de &quot;Ji Jani bolo&quot;
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={onToggleWakeWord}
                    className={`min-h-[40px] px-4 rounded-xl border text-xs font-semibold cursor-pointer ${
                      wakeWordEnabled
                        ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200'
                        : 'border-slate-700 bg-slate-950 text-slate-300'
                    }`}
                  >
                    {wakeWordEnabled ? 'Active' : 'Off'}
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {(['roman-urdu', 'urdu-script', 'english'] as const).map((lang) => (
                    <button
                      key={lang}
                      type="button"
                      onClick={() => onUpdateCharacter({ ...character, language: lang })}
                      className={`min-h-[40px] rounded-xl border text-xs font-medium cursor-pointer ${
                        character.language === lang
                          ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                          : 'border-slate-700 text-slate-400'
                      }`}
                    >
                      {lang === 'roman-urdu'
                        ? 'Roman Urdu'
                        : lang === 'urdu-script'
                        ? 'اردو Script'
                        : 'English'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Phone Install & ZIP Download */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                <div className="flex items-center gap-2 text-cyan-300 text-sm font-semibold">
                  <Smartphone className="w-4 h-4" />
                  <span>Phone Install &amp; Source / APK Export</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={onDownloadZip}
                    className={`min-h-[46px] rounded-xl bg-gradient-to-r from-cyan-600 to-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                      canInstallPwa ? '' : 'sm:col-span-2'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Source + APK ZIP</span>
                  </button>

                  {canInstallPwa && (
                    <button
                      type="button"
                      onClick={onInstallPwa}
                      className="min-h-[46px] rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Smartphone className="w-4 h-4" />
                      <span>Install App on Phone</span>
                    </button>
                  )}
                </div>

                <div className="rounded-xl border border-cyan-500/25 bg-slate-950/80 p-3 space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
                  <p className="font-semibold text-cyan-300">
                    Android Phone &amp; .APK Banane Ke 3 Asaan Tareeqe:
                  </p>
                  <p>
                    1. <strong>10-Second Phone Install:</strong> Apne phone ke Chrome mein yeh link
                    kholen → 3 dots (⋮) → <strong>Install app / Add to Home screen</strong> tap karein.
                  </p>
                  <p>
                    2. <strong>Direct .APK (1 Minute):</strong>{' '}
                    <a
                      href="https://www.pwabuilder.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-300 underline"
                    >
                      pwabuilder.com
                    </a>{' '}
                    par Shared App URL paste karke Android APK package download karein.
                  </p>
                  <p>
                    3. <strong>CodeAssist / GitHub Cloud APK:</strong> Upar se{' '}
                    <strong>Source + APK ZIP</strong> download karein — is mein{' '}
                    <code className="text-cyan-200">android-apk/</code> aur GitHub Actions{' '}
                    <code className="text-cyan-200">build-apk.yml</code> pehle se ready hai.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
