import { type FormEvent } from 'react';
import {
  Camera,
  Code2,
  Globe,
  MapPin,
  MessageCircle,
  MessageSquare,
  Mic,
  MicOff,
  Pencil,
  Phone,
  Rocket,
  ScanText,
  Search,
  Send,
  Trash2,
  Volume2,
  Youtube,
  Zap,
  BellRing,
} from 'lucide-react';
import type {
  ActionGridTool,
  ActiveToolModal,
  ChatMessage,
  NaziaStatus,
  ReminderItem,
} from '../types';
import { HologramCore } from './HologramCore';

interface ClassicDashboardProps {
  status: NaziaStatus;
  micLevel: number;
  isListening: boolean;
  isSpeaking: boolean;
  interimText: string;
  latestBubbleText: string;
  inputText: string;
  activeTool: ActionGridTool;
  messages: ChatMessage[];
  reminders: ReminderItem[];
  onInputChange: (val: string) => void;
  onSendCommand: (text?: string, toolOverride?: ActionGridTool) => void;
  onToggleMic: () => void;
  onSelectTool: (tool: ActionGridTool) => void;
  onOpenModal: (modal: ActiveToolModal) => void;
  onDeleteReminder: (id: string) => void;
  onToggleReminder: (id: string) => void;
  onSpeakText: (text: string) => void;
}

const ACTION_CARDS: Array<{
  id: ActionGridTool;
  title: string;
  subtitle: string;
  icon: typeof MessageSquare;
}> = [
  { id: 'chat', title: 'Chat', subtitle: 'Ask Nazia', icon: MessageSquare },
  { id: 'voice', title: 'Voice Assistant', subtitle: 'Tap to Speak', icon: Mic },
  { id: 'search', title: 'AI Search', subtitle: 'Internet', icon: Search },
  { id: 'code', title: 'Code Help', subtitle: 'Ask coding questions', icon: Code2 },
  { id: 'screen', title: 'Screen Assist', subtitle: 'Read screen', icon: ScanText },
  { id: 'phone', title: 'Phone Control', subtitle: 'Phone settings', icon: Phone },
];

export function ClassicDashboard({
  status,
  micLevel,
  isListening,
  isSpeaking,
  interimText,
  latestBubbleText,
  inputText,
  activeTool,
  messages,
  reminders,
  onInputChange,
  onSendCommand,
  onToggleMic,
  onSelectTool,
  onOpenModal,
  onDeleteReminder,
  onToggleReminder,
  onSpeakText,
}: ClassicDashboardProps) {
  function handleFormSubmit(e: FormEvent) {
    e.preventDefault();
    if (inputText.trim()) {
      onSendCommand(inputText);
    }
  }

  const pendingReminders = reminders.filter((r) => !r.completed);

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 pb-8 grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left/Primary Column: Faithful Mobile Mockup HUD */}
      <section className="lg:col-span-7 flex flex-col gap-3.5">
        {/* Hero Hologram + Speech Bubble Card */}
        <div className="relative rounded-3xl border border-cyan-500/35 bg-gradient-to-b from-slate-900/85 via-[#070d24]/90 to-slate-950/95 p-4 shadow-[0_0_35px_rgba(6,182,212,0.16)] overflow-hidden">
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-5">
            <div className="shrink-0">
              <HologramCore
                status={status}
                mode="classic"
                micLevel={micLevel}
                size="md"
                showWaveform={true}
                onTap={onToggleMic}
              />
            </div>

            <div className="flex-1 min-w-0">
              <div className="relative rounded-2xl border border-cyan-400/50 bg-slate-950/80 p-3.5 shadow-[0_0_24px_rgba(34,211,238,0.2)]">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span className="font-display text-lg sm:text-xl font-bold text-white">
                      Hello Jani!
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSpeakText(latestBubbleText)}
                    aria-label="Replay Nazia voice"
                    className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-cyan-300 hover:bg-cyan-500/15 transition-colors cursor-pointer"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs sm:text-sm text-cyan-100/95 leading-relaxed line-clamp-4">
                  {interimText ? `Sun rahi hoon: "${interimText}"` : latestBubbleText}
                </p>
              </div>

              {/* READY - TAP VOICE + Big Mic Button */}
              <div className="mt-3 flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={onToggleMic}
                  className={`flex-1 min-h-[46px] rounded-full border px-4 flex items-center justify-center gap-2.5 text-xs sm:text-sm font-semibold tracking-wide transition-all cursor-pointer ${
                    isListening
                      ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200 shadow-[0_0_24px_rgba(16,185,129,0.4)]'
                      : isSpeaking
                      ? 'border-cyan-400 bg-cyan-500/20 text-cyan-100 shadow-[0_0_20px_rgba(34,211,238,0.35)]'
                      : 'border-emerald-400/75 bg-emerald-950/45 text-emerald-200 hover:bg-emerald-900/50 shadow-[0_0_16px_rgba(16,185,129,0.25)]'
                  }`}
                >
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      isListening
                        ? 'bg-emerald-400 animate-ping'
                        : 'bg-emerald-400'
                    }`}
                  />
                  <span className="truncate">
                    {isListening
                      ? 'LISTENING - TAP STOP'
                      : isSpeaking
                      ? 'NAZIA SPEAKING...'
                      : 'READY - TAP VOICE'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={onToggleMic}
                  aria-label={isListening ? 'Stop voice listening' : 'Tap microphone to speak'}
                  className={`w-14 h-14 shrink-0 rounded-full border-2 flex items-center justify-center transition-all cursor-pointer ${
                    isListening
                      ? 'border-emerald-400 bg-emerald-500/25 text-emerald-200 shadow-[0_0_28px_rgba(16,185,129,0.6)] scale-105'
                      : 'border-cyan-400 bg-slate-900/90 text-cyan-300 shadow-[0_0_22px_rgba(34,211,238,0.45)] hover:bg-cyan-950/60'
                  }`}
                >
                  {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Urdu Input Box */}
        <form
          onSubmit={handleFormSubmit}
          className="relative flex items-center rounded-full border border-violet-500/60 bg-slate-950/90 px-3 py-1.5 shadow-[0_0_24px_rgba(139,92,246,0.22)] focus-within:border-cyan-400 transition-colors"
        >
          <span className="w-9 h-9 flex items-center justify-center text-cyan-400 shrink-0">
            <Pencil className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={inputText}
            onChange={(e) => onInputChange(e.target.value)}
            placeholder="اپنا سوال یا حکم لکھیں... (apna sawal ya hukum likhein...)"
            className="flex-1 min-h-[44px] bg-transparent px-2 text-sm text-white placeholder-slate-400 focus:outline-none text-right sm:text-left"
          />
          <button
            type="submit"
            aria-label="Send Urdu command"
            className="min-w-[44px] min-h-[44px] rounded-full flex items-center justify-center text-violet-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors cursor-pointer"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>

        {/* 6 Neon Action Cards (2x3 Grid) */}
        <div className="grid grid-cols-2 gap-3">
          {ACTION_CARDS.map((card) => {
            const Icon = card.icon;
            const selected = activeTool === card.id;
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => onSelectTool(card.id)}
                className={`min-h-[82px] rounded-2xl border p-3.5 flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  selected
                    ? 'border-cyan-300 bg-gradient-to-b from-cyan-500/25 to-blue-900/45 shadow-[0_0_26px_rgba(34,211,238,0.35)]'
                    : 'border-cyan-500/45 bg-gradient-to-b from-slate-900/90 to-[#07112b]/95 hover:border-cyan-400/80 shadow-[0_0_16px_rgba(6,182,212,0.12)]'
                }`}
              >
                <Icon className="w-6 h-6 text-cyan-300 mb-1.5 drop-shadow-[0_0_8px_rgba(34,211,238,0.7)]" />
                <span className="font-display text-sm sm:text-base font-semibold text-white leading-tight">
                  {card.title}
                </span>
                <span className="text-[11px] text-slate-300 mt-0.5 leading-tight">
                  {card.subtitle}
                </span>
              </button>
            );
          })}
        </div>

        {/* Quick Actions Row */}
        <div className="rounded-2xl border border-slate-800/80 bg-slate-950/75 px-3 py-3">
          <div className="flex items-center justify-between mb-2.5 px-1">
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              <span className="font-display text-sm font-semibold text-cyan-200">
                Quick Actions
              </span>
            </div>
            <button
              type="button"
              onClick={() => onOpenModal('reminders')}
              className="text-xs text-cyan-300 hover:text-cyan-200 flex items-center gap-1 cursor-pointer min-h-[32px] px-2"
            >
              <BellRing className="w-3.5 h-3.5" />
              <span className="tabular-nums">Reminders ({pendingReminders.length})</span>
            </button>
          </div>

          <div className="grid grid-cols-5 gap-2">
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-1 min-h-[48px] group"
            >
              <span className="w-11 h-11 rounded-full bg-red-600/90 border border-red-400/60 flex items-center justify-center text-white shadow-[0_0_14px_rgba(239,68,68,0.4)] group-hover:scale-105 transition-transform">
                <Youtube className="w-5 h-5" />
              </span>
              <span className="text-[11px] text-slate-300">YouTube</span>
            </a>

            <a
              href="https://wa.me/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-1 min-h-[48px] group"
            >
              <span className="w-11 h-11 rounded-full bg-emerald-600/90 border border-emerald-400/60 flex items-center justify-center text-white shadow-[0_0_14px_rgba(16,185,129,0.4)] group-hover:scale-105 transition-transform">
                <MessageCircle className="w-5 h-5" />
              </span>
              <span className="text-[11px] text-slate-300">WhatsApp</span>
            </a>

            <button
              type="button"
              onClick={() => onOpenModal('camera')}
              className="flex flex-col items-center gap-1 min-h-[48px] group cursor-pointer"
            >
              <span className="w-11 h-11 rounded-full bg-sky-600/90 border border-sky-400/60 flex items-center justify-center text-white shadow-[0_0_14px_rgba(14,165,233,0.4)] group-hover:scale-105 transition-transform">
                <Camera className="w-5 h-5" />
              </span>
              <span className="text-[11px] text-slate-300">Camera</span>
            </button>

            <a
              href="https://www.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-1 min-h-[48px] group"
            >
              <span className="w-11 h-11 rounded-full bg-blue-600/90 border border-cyan-400/60 flex items-center justify-center text-white shadow-[0_0_14px_rgba(59,130,246,0.45)] group-hover:scale-105 transition-transform">
                <Globe className="w-5 h-5" />
              </span>
              <span className="text-[11px] text-slate-300">Browser</span>
            </a>

            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-1 min-h-[48px] group"
            >
              <span className="w-11 h-11 rounded-full bg-teal-600/90 border border-emerald-300/60 flex items-center justify-center text-white shadow-[0_0_14px_rgba(20,184,166,0.45)] group-hover:scale-105 transition-transform">
                <MapPin className="w-5 h-5" />
              </span>
              <span className="text-[11px] text-slate-300">Maps</span>
            </a>
          </div>
        </div>

        {/* Bottom SEND MESSAGE CTA */}
        <button
          type="button"
          onClick={() => {
            if (inputText.trim()) {
              onSendCommand(inputText);
            } else {
              onOpenModal('chat');
            }
          }}
          className="w-full min-h-[54px] rounded-full border border-cyan-400/65 bg-gradient-to-r from-[#06183a] via-[#0b2354] to-[#1a134b] px-5 flex items-center justify-between shadow-[0_0_28px_rgba(6,182,212,0.28)] hover:border-cyan-300 active:scale-[0.99] transition-all cursor-pointer"
        >
          <Rocket className="w-5 h-5 text-cyan-400" />
          <span className="font-display text-sm sm:text-base font-bold tracking-wider text-white flex items-center gap-2">
            SEND MESSAGE
            <Send className="w-4 h-4 text-cyan-300" />
          </span>
          <div className="flex items-center gap-0.5 h-5" aria-hidden="true">
            {[0.4, 0.85, 0.55, 1, 0.7, 0.45, 0.9, 0.5].map((v, i) => (
              <span
                key={i}
                className="w-0.5 rounded-full bg-cyan-400"
                style={{ height: `${Math.round(v * 100)}%` }}
              />
            ))}
          </div>
        </button>
      </section>

      {/* Right Column: Live Chat Feed & Pending Reminders (Desktop + Below on Mobile) */}
      <aside className="lg:col-span-5 flex flex-col gap-4">
        {/* Conversation Feed */}
        <div className="rounded-3xl border border-slate-800 bg-slate-950/80 p-4 flex flex-col min-h-[300px] lg:h-[430px]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Nazia Conversation
              </h2>
              <p className="text-xs text-slate-400">
                Mode: {activeTool} · Free Urdu AI & Command Engine
              </p>
            </div>
            <button
              type="button"
              onClick={() => onOpenModal('chat')}
              className="min-h-[36px] px-3 rounded-lg border border-cyan-500/35 text-xs font-medium text-cyan-300 hover:bg-cyan-500/10 cursor-pointer"
            >
              Expand Chat
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-3 space-y-3 pr-1">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-violet-600/30 border border-violet-400/40 text-white'
                      : 'bg-slate-900/95 border border-cyan-500/30 text-slate-100'
                  }`}
                >
                  {msg.imagePreview && (
                    <img
                      src={msg.imagePreview}
                      alt="Captured screen or camera input"
                      className="w-full max-h-36 object-cover rounded-xl mb-2 border border-cyan-500/30"
                    />
                  )}
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-slate-700/60 flex flex-wrap gap-2">
                      {msg.sources.slice(0, 3).map((src, idx) => (
                        <a
                          key={idx}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] text-cyan-300 underline hover:text-cyan-200 truncate max-w-[200px]"
                        >
                          {src.title}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
                <span className="mt-1 px-1 text-[11px] text-slate-500 tabular-nums">
                  {msg.role === 'user' ? 'Jani' : 'Nazia'} · {msg.timestamp}
                </span>
              </div>
            ))}
          </div>

          {/* Quick Urdu Suggestion Prompts */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-wrap gap-1.5">
            {[
              'Nazia kal 5 baje yaad dilana',
              'Nazia aaj ka mausam batao',
              'TikTok video plan do',
              'Online earning tareeqa batao',
            ].map((sample) => (
              <button
                key={sample}
                type="button"
                onClick={() => onSendCommand(sample)}
                className="min-h-[34px] px-2.5 py-1 rounded-lg border border-slate-700/80 bg-slate-900/80 text-[11px] text-slate-300 hover:border-cyan-400/60 hover:text-cyan-200 transition-colors cursor-pointer"
              >
                {sample}
              </button>
            ))}
          </div>
        </div>

        {/* Smart Reminders Quick Card */}
        <div className="rounded-3xl border border-slate-800 bg-slate-950/80 p-4">
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-800/80">
            <h2 className="font-display text-base font-semibold text-white">
              Smart Reminders & Tasks
            </h2>
            <button
              type="button"
              onClick={() => onOpenModal('reminders')}
              className="text-xs font-medium text-cyan-300 hover:text-cyan-200 cursor-pointer min-h-[32px] px-2"
            >
              Manage All
            </button>
          </div>

          {reminders.length === 0 ? (
            <p className="py-4 text-xs text-slate-400">
              Abhi koi reminder nahi hai. Bolo ya likho: &quot;Nazia kal 5 baje yaad dilana&quot;
            </p>
          ) : (
            <ul className="divide-y divide-slate-800/70 max-h-48 overflow-y-auto">
              {reminders.slice(0, 5).map((item) => (
                <li
                  key={item.id}
                  className="py-2.5 flex items-center justify-between gap-3"
                >
                  <button
                    type="button"
                    onClick={() => onToggleReminder(item.id)}
                    className="flex-1 text-left cursor-pointer min-h-[36px]"
                  >
                    <p
                      className={`text-sm font-medium ${
                        item.completed ? 'line-through text-slate-500' : 'text-slate-100'
                      }`}
                    >
                      {item.title}
                    </p>
                    <p className="text-xs text-cyan-300/80 tabular-nums">{item.dueText}</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteReminder(item.id)}
                    aria-label={`Delete reminder ${item.title}`}
                    className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </aside>
    </div>
  );
}
