import { useEffect, useRef, useState, type ChangeEvent } from 'react';
import {
  BatteryCharging,
  Cast,
  ClipboardCopy,
  Laptop,
  Maximize2,
  MessageCircle,
  MessageSquare,
  Monitor,
  Phone,
  PhoneCall,
  PictureInPicture2,
  Radio,
  ScanText,
  Send,
  Share2,
  Smartphone,
  Sun,
  Upload,
  Volume2,
  Wifi,
  Youtube,
} from 'lucide-react';
import type { BridgeDevice, MemoryProfile, NaziaStatus } from '../types';
import { HologramCore } from './HologramCore';

interface PhoneScreenControlProps {
  status: NaziaStatus;
  micLevel: number;
  latestBubbleText: string;
  memory: MemoryProfile;
  thisDeviceId: string;
  thisDeviceType: 'phone' | 'laptop';
  bridgeDevices: BridgeDevice[];
  pipActive: boolean;
  onTogglePip: () => void;
  onToggleMic: () => void;
  onAnalyzeScreenImage: (prompt: string, imageBase64: string) => void;
  onSendBridgeCommand: (
    targetId: string,
    action: 'speak' | 'open_url' | 'clipboard' | 'ring' | 'launch_app',
    payload: string
  ) => Promise<void>;
  onSimulateCall: () => void;
}

export function PhoneScreenControl({
  status,
  micLevel,
  latestBubbleText,
  memory,
  thisDeviceId,
  thisDeviceType,
  bridgeDevices,
  pipActive,
  onTogglePip,
  onToggleMic,
  onAnalyzeScreenImage,
  onSendBridgeCommand,
  onSimulateCall,
}: PhoneScreenControlProps) {
  const [screenSharing, setScreenSharing] = useState(false);
  const [screenError, setScreenError] = useState<string | null>(null);
  const [screenQuestion, setScreenQuestion] = useState(
    'Nazia meri shared screen parh kar Urdu mein batao kya likha hai aur kya karna chahiye'
  );

  const [battery, setBattery] = useState<{ level: number; charging: boolean } | null>(null);
  const [netLabel, setNetLabel] = useState('Online');
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const [phoneNum, setPhoneNum] = useState('');
  const [waMessage, setWaMessage] = useState('Assalam o alaikum!');
  const [ytQuery, setYtQuery] = useState('');

  const [selectedTarget, setSelectedTarget] = useState<string>('all');
  const [remoteText, setRemoteText] = useState('');
  const [bridgeFeedback, setBridgeFeedback] = useState<string | null>(null);

  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const wakeLockRef = useRef<{ release: () => Promise<void> } | null>(null);

  useEffect(() => {
    const nav = navigator as unknown as {
      getBattery?: () => Promise<{ level: number; charging: boolean }>;
      connection?: { effectiveType?: string; downlink?: number };
    };
    nav.getBattery?.()
      .then((b) => setBattery({ level: Math.round(b.level * 100), charging: b.charging }))
      .catch(() => {});

    if (nav.connection) {
      setNetLabel(
        `${(nav.connection.effectiveType || 'wifi').toUpperCase()} · ${nav.connection.downlink ?? '--'} Mbps`
      );
    } else {
      setNetLabel(navigator.onLine ? 'Connected' : 'Offline');
    }

    return () => {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      wakeLockRef.current?.release().catch(() => {});
    };
  }, []);

  async function startScreenShare() {
    setScreenError(null);
    if (!navigator.mediaDevices?.getDisplayMedia) {
      setScreenError(
        'Mobile browser par direct Screen Share blocked ho sakta hai — neeche se Screenshot upload karein ya Laptop par Start Screen Share dabayein.'
      );
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: false,
      });
      screenStreamRef.current = stream;
      if (screenVideoRef.current) {
        screenVideoRef.current.srcObject = stream;
      }
      setScreenSharing(true);
      const track = stream.getVideoTracks()[0];
      if (track) {
        track.onended = () => {
          setScreenSharing(false);
          screenStreamRef.current = null;
        };
      }
    } catch {
      setScreenError('Screen sharing cancel ho gayi ya browser ne ijazat nahi di.');
    }
  }

  function stopScreenShare() {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
    }
    if (screenVideoRef.current) {
      screenVideoRef.current.srcObject = null;
    }
    setScreenSharing(false);
  }

  function captureAndReadSharedScreen() {
    const video = screenVideoRef.current;
    if (!video || !video.videoWidth) {
      setScreenError('Pehle "Start Screen Share" dabayein ya screenshot upload karein.');
      return;
    }
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d')?.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    onAnalyzeScreenImage(screenQuestion, dataUrl);
  }

  function handleScreenshotUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onAnalyzeScreenImage(screenQuestion, reader.result);
      }
    };
    reader.readAsDataURL(file);
  }

  async function toggleWakeLock() {
    const nav = navigator as unknown as {
      wakeLock?: { request: (type: 'screen') => Promise<{ release: () => Promise<void> }> };
    };
    if (wakeLockActive) {
      await wakeLockRef.current?.release().catch(() => {});
      wakeLockRef.current = null;
      setWakeLockActive(false);
      return;
    }
    try {
      if (nav.wakeLock) {
        wakeLockRef.current = await nav.wakeLock.request('screen');
        setWakeLockActive(true);
      }
    } catch {
      setScreenError('Screen Wake Lock is browser par supported nahi.');
    }
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }

  async function sendRemote(
    action: 'speak' | 'open_url' | 'clipboard' | 'ring' | 'launch_app',
    payload: string
  ) {
    await onSendBridgeCommand(selectedTarget, action, payload);
    setBridgeFeedback(`Command "${action}" bhej di gayi hai!`);
    setTimeout(() => setBridgeFeedback(null), 3000);
  }

  const otherDevices = bridgeDevices.filter((d) => d.id !== thisDeviceId);
  const cleanDigits = phoneNum.replace(/[^\d+]/g, '');

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 pb-10 space-y-5">
      {/* Top Banner: Nazia Always On Display (Floating PiP) + Live Status */}
      <div className="rounded-3xl border border-cyan-500/40 bg-gradient-to-r from-slate-950 via-[#071430] to-slate-950 p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-[0_0_32px_rgba(6,182,212,0.18)]">
        <div className="flex items-center gap-4">
          <HologramCore
            status={status}
            mode="classic"
            micLevel={micLevel}
            size="sm"
            showWaveform={true}
            onTap={onToggleMic}
          />
          <div className="min-w-0">
            <h1 className="font-display text-lg sm:text-xl font-bold text-white">
              Phone &amp; Laptop Control · Screen Sharing
            </h1>
            <p className="text-xs sm:text-sm text-cyan-200/90 mt-1 line-clamp-2">
              {latestBubbleText}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <button
            type="button"
            onClick={onTogglePip}
            className={`flex-1 md:flex-none min-h-[46px] px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all ${
              pipActive
                ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200 shadow-[0_0_20px_rgba(16,185,129,0.35)]'
                : 'border-cyan-400/70 bg-cyan-500/20 text-cyan-100 hover:bg-cyan-500/30'
            }`}
          >
            <PictureInPicture2 className="w-4 h-4" />
            <span>{pipActive ? 'Nazia Floating ON' : 'Float Nazia On Display'}</span>
          </button>

          <button
            type="button"
            onClick={toggleWakeLock}
            className={`min-h-[46px] px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              wakeLockActive
                ? 'border-amber-400 bg-amber-500/20 text-amber-200'
                : 'border-slate-700 bg-slate-900 text-slate-300'
            }`}
          >
            <Sun className="w-4 h-4" />
            <span>Screen ON: {wakeLockActive ? 'YES' : 'NO'}</span>
          </button>

          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label="Toggle fullscreen"
            className="min-h-[46px] px-3.5 rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
          >
            <Maximize2 className="w-4 h-4" />
            <span>Full</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Screen Sharing (Left 7 cols) + Phone & Laptop Control (Right 5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Live Screen Sharing & AI Screen Reader */}
        <section className="lg:col-span-7 rounded-3xl border border-cyan-500/35 bg-slate-950/90 p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Cast className="w-5 h-5 text-cyan-400" />
              <h2 className="font-display text-base sm:text-lg font-bold text-white">
                Live Screen Sharing &amp; Nazia Screen Reader
              </h2>
            </div>

            <div className="flex items-center gap-2">
              {!screenSharing ? (
                <button
                  type="button"
                  onClick={startScreenShare}
                  className="min-h-[42px] px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-[0_0_18px_rgba(6,182,212,0.35)]"
                >
                  <Monitor className="w-4 h-4" />
                  <span>Start Screen Share</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={stopScreenShare}
                  className="min-h-[42px] px-4 rounded-xl bg-rose-600 text-white text-xs font-semibold cursor-pointer"
                >
                  Stop Sharing
                </button>
              )}

              <label className="min-h-[42px] px-3.5 rounded-xl border border-violet-500/50 bg-violet-500/15 text-violet-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer">
                <Upload className="w-4 h-4" />
                <span>Screenshot</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleScreenshotUpload}
                  className="sr-only"
                />
              </label>
            </div>
          </div>

          {/* Live Screen Preview */}
          <div className="relative rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden min-h-[240px] sm:min-h-[300px] flex items-center justify-center">
            <video
              ref={screenVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full max-h-[340px] object-contain ${screenSharing ? 'block' : 'hidden'}`}
            />
            {!screenSharing && (
              <div className="text-center px-6 py-8 space-y-2">
                <Monitor className="w-10 h-10 text-cyan-400/70 mx-auto" />
                <p className="text-sm font-semibold text-white">
                  Screen Sharing Abhi Band Hai
                </p>
                <p className="text-xs text-slate-400 max-w-md">
                  &quot;Start Screen Share&quot; dabayein taake Nazia aap ki laptop/phone screen
                  live dekhe aur parh kar Urdu mein madad kare.
                </p>
              </div>
            )}
          </div>

          {screenError && (
            <div className="rounded-xl border border-amber-500/40 bg-amber-950/30 px-3.5 py-2.5 text-xs text-amber-200">
              {screenError}
            </div>
          )}

          {/* Read Screen Question & Trigger */}
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={screenQuestion}
              onChange={(e) => setScreenQuestion(e.target.value)}
              placeholder="Screen ke baray mein kya poochna hai?"
              className="flex-1 min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3.5 text-xs sm:text-sm text-white focus:border-cyan-400 focus:outline-none"
            />
            <button
              type="button"
              onClick={captureAndReadSharedScreen}
              className="min-h-[44px] px-4 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              <ScanText className="w-4 h-4" />
              <span>Nazia Screen Parho</span>
            </button>
          </div>
        </section>

        {/* Right Column: Laptop <-> Phone Bridge + Local Phone Controls */}
        <div className="lg:col-span-5 space-y-5">
          {/* Phone <-> Laptop Remote Control Bridge */}
          <section className="rounded-3xl border border-violet-500/35 bg-slate-950/90 p-4 sm:p-5 space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-violet-400" />
                <h2 className="font-display text-base font-bold text-white">
                  Phone &amp; Laptop Live Control Bridge
                </h2>
              </div>
              <span className="text-xs text-cyan-300 tabular-nums">
                {bridgeDevices.length} Online
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Isi Nazia AI link ko apne <strong>Phone</strong> aur <strong>Laptop</strong> dono
              par kholein (ya ZIP wala <code className="text-cyan-300">nazia-laptop-agent.mjs</code>{' '}
              laptop par chalayein) — ek device se dusray ko control karein!
            </p>

            {/* Connected Devices Selector */}
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setSelectedTarget('all')}
                className={`min-h-[36px] px-3 rounded-xl border text-xs font-medium cursor-pointer ${
                  selectedTarget === 'all'
                    ? 'border-cyan-400 bg-cyan-500/20 text-cyan-100'
                    : 'border-slate-700 text-slate-300'
                }`}
              >
                All Devices ({bridgeDevices.length})
              </button>
              {otherDevices.map((dev) => (
                <button
                  key={dev.id}
                  type="button"
                  onClick={() => setSelectedTarget(dev.id)}
                  className={`min-h-[36px] px-3 rounded-xl border text-xs font-medium flex items-center gap-1.5 cursor-pointer ${
                    selectedTarget === dev.id
                      ? 'border-emerald-400 bg-emerald-500/20 text-emerald-100'
                      : 'border-slate-700 text-slate-300'
                  }`}
                >
                  {dev.deviceType === 'phone' ? (
                    <Smartphone className="w-3.5 h-3.5" />
                  ) : (
                    <Laptop className="w-3.5 h-3.5" />
                  )}
                  <span>{dev.name}</span>
                </button>
              ))}
            </div>

            {/* Remote Command Box */}
            <div className="flex gap-2">
              <input
                type="text"
                value={remoteText}
                onChange={(e) => setRemoteText(e.target.value)}
                placeholder="Link (https://...) ya Urdu bolne ka paigham..."
                className="flex-1 min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white placeholder-slate-500 focus:border-violet-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  const val = remoteText.trim();
                  if (!val) return;
                  if (/^https?:\/\//i.test(val)) {
                    sendRemote('open_url', val);
                  } else {
                    sendRemote('speak', val);
                  }
                  setRemoteText('');
                }}
                className="min-h-[42px] px-3.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </div>

            {/* Quick Remote Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              <button
                type="button"
                onClick={() => sendRemote('open_url', 'https://www.youtube.com')}
                className="min-h-[38px] rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Open YouTube
              </button>
              <button
                type="button"
                onClick={() => sendRemote('ring', 'Jani phone/laptop dhoond rahe hain!')}
                className="min-h-[38px] rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Ring / Find Device
              </button>
              <button
                type="button"
                onClick={() => sendRemote('launch_app', 'chrome')}
                className="min-h-[38px] rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Laptop Chrome
              </button>
              <button
                type="button"
                onClick={() => sendRemote('launch_app', 'explorer')}
                className="min-h-[38px] rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Laptop Files
              </button>
              <button
                type="button"
                onClick={() => sendRemote('launch_app', 'calculator')}
                className="min-h-[38px] rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 cursor-pointer"
              >
                Laptop Calc
              </button>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard
                    ?.readText()
                    .then((txt) => {
                      if (txt) sendRemote('clipboard', txt);
                    })
                    .catch(() => {});
                }}
                className="min-h-[38px] rounded-xl border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400 flex items-center justify-center gap-1 cursor-pointer"
              >
                <ClipboardCopy className="w-3.5 h-3.5" />
                <span>Sync Copy</span>
              </button>
            </div>

            {bridgeFeedback && (
              <p className="text-xs text-emerald-300 font-medium">{bridgeFeedback}</p>
            )}
          </section>

          {/* Direct Local Phone Actions + Telemetry */}
          <section className="rounded-3xl border border-slate-800 bg-slate-950/90 p-4 sm:p-5 space-y-3.5">
            <h2 className="font-display text-base font-bold text-white">
              Direct Phone &amp; System Control ({thisDeviceType.toUpperCase()})
            </h2>

            {/* Call / SMS / WhatsApp */}
            <div className="space-y-2">
              <input
                type="tel"
                value={phoneNum}
                onChange={(e) => setPhoneNum(e.target.value)}
                placeholder="Phone number likhein (e.g. +923001234567)"
                className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
              />
              <input
                type="text"
                value={waMessage}
                onChange={(e) => setWaMessage(e.target.value)}
                placeholder="WhatsApp / SMS message..."
                className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
              />
              <div className="grid grid-cols-3 gap-2 text-xs">
                <a
                  href={cleanDigits ? `tel:${cleanDigits}` : 'tel:'}
                  className="min-h-[42px] rounded-xl bg-sky-600/85 hover:bg-sky-500 text-white font-semibold flex items-center justify-center gap-1.5"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call</span>
                </a>
                <a
                  href={
                    cleanDigits
                      ? `sms:${cleanDigits}?body=${encodeURIComponent(waMessage)}`
                      : `sms:?body=${encodeURIComponent(waMessage)}`
                  }
                  className="min-h-[42px] rounded-xl bg-indigo-600/85 hover:bg-indigo-500 text-white font-semibold flex items-center justify-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>SMS</span>
                </a>
                <a
                  href={`https://wa.me/${cleanDigits.replace(/\+/g, '')}?text=${encodeURIComponent(waMessage)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[42px] rounded-xl bg-emerald-600/90 hover:bg-emerald-500 text-white font-semibold flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>

            {/* YouTube Direct Search */}
            <div className="flex gap-2">
              <input
                type="text"
                value={ytQuery}
                onChange={(e) => setYtQuery(e.target.value)}
                placeholder="YouTube par kya chalayein?"
                className="flex-1 min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white placeholder-slate-500 focus:border-red-400 focus:outline-none"
              />
              <a
                href={
                  ytQuery.trim()
                    ? `https://www.youtube.com/results?search_query=${encodeURIComponent(ytQuery.trim())}`
                    : 'https://www.youtube.com'
                }
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[42px] px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Youtube className="w-4 h-4" />
                <span>Play</span>
              </a>
            </div>

            {/* Live Device Stats */}
            <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
              <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-2.5">
                <div className="flex items-center gap-1 text-emerald-300 text-[11px]">
                  <BatteryCharging className="w-3.5 h-3.5" />
                  <span>Battery</span>
                </div>
                <p className="font-bold text-white mt-0.5 tabular-nums">
                  {battery ? `${battery.level}%` : 'Protected'}
                </p>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-2.5">
                <div className="flex items-center gap-1 text-cyan-300 text-[11px]">
                  <Wifi className="w-3.5 h-3.5" />
                  <span>Net</span>
                </div>
                <p className="font-bold text-white mt-0.5 truncate">{netLabel}</p>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-2.5">
                <div className="flex items-center gap-1 text-violet-300 text-[11px]">
                  <Phone className="w-3.5 h-3.5" />
                  <span>Inverter</span>
                </div>
                <p className="font-bold text-white mt-0.5 truncate">
                  {memory.inverterSystem || 'Ready'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={onSimulateCall}
                className="min-h-[40px] rounded-xl border border-violet-500/45 bg-violet-500/15 text-violet-200 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Call Alert Test</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  navigator.share?.({
                    title: 'Nazia AI',
                    text: 'Meri personal AI assistant Nazia AI',
                    url: window.location.href,
                  }).catch(() => {});
                }}
                className="min-h-[40px] rounded-xl border border-cyan-500/45 bg-cyan-500/15 text-cyan-200 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share Link</span>
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
