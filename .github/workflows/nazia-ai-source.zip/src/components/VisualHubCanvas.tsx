import { useEffect, useRef } from 'react';
import type { VisualPresetId } from '../types';

interface VisualHubCanvasProps {
  preset: VisualPresetId;
}

export function VisualHubCanvas({ preset }: VisualHubCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let tick = 0;

    const render = () => {
      tick += 0.02;
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // Deep space grid backdrop
      const bg = ctx.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w * 0.7);
      bg.addColorStop(0, '#0f172a');
      bg.addColorStop(1, '#020617');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // Subtle starfield
      for (let i = 0; i < 42; i++) {
        const sx = ((i * 97) % w);
        const sy = ((i * 53 + Math.sin(tick + i) * 3) % h);
        ctx.fillStyle = `rgba(186, 230, 253, ${0.25 + ((i % 5) * 0.12)})`;
        ctx.fillRect(sx, sy, 1.5, 1.5);
      }

      const cx = w / 2;
      const cy = h / 2;

      if (preset === 'blackhole') {
        // Accretion disk rings
        for (let r = 85; r >= 38; r -= 7) {
          ctx.beginPath();
          ctx.ellipse(cx, cy, r * 1.45, r * 0.45, 0.22, 0, Math.PI * 2);
          ctx.strokeStyle = r > 60 ? 'rgba(168,85,247,0.45)' : 'rgba(34,211,238,0.8)';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
        // Event horizon
        ctx.beginPath();
        ctx.arc(cx, cy, 34, 0, Math.PI * 2);
        ctx.fillStyle = '#000000';
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Orbiting plasma particle
        const px = cx + Math.cos(tick * 2.2) * 95;
        const py = cy + Math.sin(tick * 2.2) * 32;
        ctx.beginPath();
        ctx.arc(px, py, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = '#facc15';
        ctx.fill();
      } else if (preset === 'fusion') {
        // Tokamak magnetic torus rings
        for (let i = 0; i < 8; i++) {
          const angle = tick * 0.5 + (i * Math.PI) / 4;
          const rx = cx + Math.cos(angle) * 46;
          const ry = cy + Math.sin(angle) * 20;
          ctx.beginPath();
          ctx.arc(rx, ry, 28, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(34,211,238,0.45)';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
        // Core plasma ring
        ctx.beginPath();
        ctx.ellipse(cx, cy, 74, 34, 0, 0, Math.PI * 2);
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 6;
        ctx.stroke();
        ctx.beginPath();
        ctx.ellipse(cx, cy, 74, 34, 0, 0, Math.PI * 2);
        ctx.strokeStyle = '#67e8f9';
        ctx.lineWidth = 2;
        ctx.stroke();
      } else if (preset === 'mars') {
        // Earth & Mars orbital trajectories
        ctx.beginPath();
        ctx.arc(cx, cy, 52, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(56,189,248,0.35)';
        ctx.setLineDash([4, 4]);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(cx, cy, 86, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(249,115,22,0.45)';
        ctx.stroke();
        ctx.setLineDash([]);

        // Sun
        ctx.beginPath();
        ctx.arc(cx, cy, 14, 0, Math.PI * 2);
        ctx.fillStyle = '#fbbf24';
        ctx.fill();

        // Earth
        const ex = cx + Math.cos(tick * 1.1) * 52;
        const ey = cy + Math.sin(tick * 1.1) * 52;
        ctx.beginPath();
        ctx.arc(ex, ey, 6, 0, Math.PI * 2);
        ctx.fillStyle = '#38bdf8';
        ctx.fill();

        // Mars
        const mx = cx + Math.cos(tick * 0.7 + 1.2) * 86;
        const my = cy + Math.sin(tick * 0.7 + 1.2) * 86;
        ctx.beginPath();
        ctx.arc(mx, my, 8, 0, Math.PI * 2);
        ctx.fillStyle = '#f97316';
        ctx.fill();
      } else {
        // SpaceX Starship blueprint wireframe
        const bob = Math.sin(tick * 1.5) * 4;
        ctx.save();
        ctx.translate(cx, cy + bob);

        // Exhaust plume
        const plumeGrad = ctx.createLinearGradient(0, 42, 0, 92);
        plumeGrad.addColorStop(0, 'rgba(34,211,238,0.95)');
        plumeGrad.addColorStop(1, 'rgba(168,85,247,0)');
        ctx.beginPath();
        ctx.moveTo(-10, 44);
        ctx.lineTo(10, 44);
        ctx.lineTo(0, 88 + Math.sin(tick * 12) * 6);
        ctx.closePath();
        ctx.fillStyle = plumeGrad;
        ctx.fill();

        // Rocket hull
        ctx.beginPath();
        ctx.moveTo(0, -68);
        ctx.quadraticCurveTo(18, -32, 18, 44);
        ctx.lineTo(-18, 44);
        ctx.quadraticCurveTo(-18, -32, 0, -68);
        ctx.closePath();
        ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Forward & aft flaps
        ctx.beginPath();
        ctx.moveTo(-16, -24);
        ctx.lineTo(-30, -8);
        ctx.lineTo(-18, -2);
        ctx.moveTo(16, -24);
        ctx.lineTo(30, -8);
        ctx.lineTo(18, -2);
        ctx.moveTo(-18, 22);
        ctx.lineTo(-32, 44);
        ctx.lineTo(-18, 44);
        ctx.moveTo(18, 22);
        ctx.lineTo(32, 44);
        ctx.lineTo(18, 44);
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 1.8;
        ctx.stroke();

        // Viewport windows
        ctx.beginPath();
        ctx.arc(0, -24, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#67e8f9';
        ctx.fill();

        ctx.restore();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [preset]);

  return (
    <canvas
      ref={canvasRef}
      width={440}
      height={210}
      className="w-full h-48 sm:h-52 rounded-2xl border border-cyan-500/30 bg-slate-950"
    />
  );
}
