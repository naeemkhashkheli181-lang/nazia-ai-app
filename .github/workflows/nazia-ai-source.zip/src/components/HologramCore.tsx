import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import type { AppMode, NaziaStatus } from '../types';

interface HologramCoreProps {
  status: NaziaStatus;
  mode: AppMode;
  micLevel: number;
  size?: 'sm' | 'md' | 'lg';
  showWaveform?: boolean;
  showAnatomy?: boolean;
  eyesActive?: boolean;
  earsActive?: boolean;
  typingActive?: boolean;
  onTap?: () => void;
}

const WAVE_BARS = [0.35, 0.7, 0.5, 0.95, 0.65, 1.0, 0.8, 0.45, 0.9, 0.6, 0.75, 0.4];

export function HologramCore({
  status,
  mode,
  micLevel,
  size = 'md',
  showWaveform = true,
  showAnatomy = mode === 'live',
  eyesActive = false,
  earsActive = status === 'listening',
  typingActive = false,
  onTap,
}: HologramCoreProps) {
  const [imgFailed, setImgFailed] = useState(false);

  const dims =
    size === 'lg'
      ? 'w-52 h-52 sm:w-64 sm:h-64'
      : size === 'sm'
      ? 'w-28 h-28 sm:w-32 sm:h-32'
      : 'w-36 h-36 sm:w-44 sm:h-44';

  const outerSpinClass =
    status === 'speaking' || typingActive
      ? 'animate-holo-fast'
      : status === 'thinking'
      ? 'animate-holo-medium'
      : 'animate-holo-slow';

  const innerSpinClass =
    status === 'speaking' || status === 'listening' || typingActive
      ? 'animate-holo-reverse-fast'
      : 'animate-holo-reverse';

  const statusLabel =
    typingActive && status === 'speaking'
      ? 'Nazia bol aur typing kar rahi hai'
      : typingActive
      ? 'Nazia hath se typing kar rahi hai'
      : mode === 'live'
      ? status === 'speaking'
        ? 'love is speaking'
        : status === 'listening'
        ? 'love is listening'
        : status === 'thinking'
        ? 'love is thinking'
        : eyesActive && earsActive
        ? 'Nazia dekh & sun rahi hai'
        : 'love is ready'
      : status === 'speaking'
      ? 'Nazia bol rahi hai'
      : status === 'listening'
      ? 'Nazia sun rahi hai'
      : status === 'thinking'
      ? 'Nazia soch rahi hai'
      : 'Nazia ready';

  const dynamicScale =
    status === 'listening' ? 1 + micLevel * 0.08 : status === 'speaking' ? 1.04 : 1;

  const earWaveScale = earsActive ? 1 + Math.min(0.45, micLevel * 0.9) : 0.95;

  return (
    <div className="flex flex-col items-center select-none w-full">
      {/* Hologram Core + Ears + Eyes Stage */}
      <div className="relative flex items-center justify-center w-full max-w-[360px]">
        {/* Left Holographic Ear (Kaan) */}
        {showAnatomy && (
          <div
            aria-label="Nazia Left Ear Sensor"
            className="mr-1 sm:mr-2 flex flex-col items-center gap-1"
            style={{
              transform: `scale(${earWaveScale})`,
              transition: 'transform 120ms ease-out',
            }}
          >
            <svg viewBox="0 0 48 80" className="w-9 h-16 sm:w-11 sm:h-20" aria-hidden="true">
              {/* Outer acoustic sonar arcs */}
              <path
                d="M16 14 C4 26, 4 54, 16 66"
                fill="none"
                stroke={earsActive ? '#34d399' : '#22d3ee'}
                strokeOpacity={earsActive ? 0.95 : 0.4}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <path
                d="M24 22 C16 30, 16 50, 24 58"
                fill="none"
                stroke={earsActive ? '#6ee7b7' : '#38bdf8'}
                strokeOpacity={earsActive ? 0.9 : 0.35}
                strokeWidth="2"
                strokeLinecap="round"
              />
              {/* Holographic ear receiver shape */}
              <path
                d="M36 22 C28 22, 26 32, 29 40 C31 46, 29 56, 35 58 C40 59, 42 52, 40 46"
                fill="none"
                stroke={earsActive ? '#34d399' : '#38bdf8'}
                strokeWidth="2.8"
                strokeLinecap="round"
              />
              <circle
                cx="35"
                cy="40"
                r="4"
                fill={earsActive ? '#34d399' : '#22d3ee'}
                opacity={earsActive ? 0.95 : 0.55}
              />
            </svg>
            <span
              className={`text-[10px] font-medium tracking-wide ${
                earsActive ? 'text-emerald-300' : 'text-cyan-400/70'
              }`}
            >
              Kaan
            </span>
          </div>
        )}

        {/* Center Hologram Portrait + Rings + Eyes HUD */}
        <button
          type="button"
          onClick={onTap}
          aria-label={`Nazia hologram status: ${statusLabel}`}
          className={`relative ${dims} shrink-0 flex items-center justify-center rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 cursor-pointer group`}
          style={{ transform: `scale(${dynamicScale})`, transition: 'transform 140ms ease-out' }}
        >
          {/* Ambient radial glow */}
          <div
            className={`absolute inset-0 rounded-full blur-2xl transition-opacity duration-300 ${
              status === 'speaking'
                ? 'bg-cyan-400/40 opacity-100'
                : status === 'listening'
                ? 'bg-emerald-400/35 opacity-95'
                : status === 'thinking'
                ? 'bg-violet-500/40 opacity-95'
                : 'bg-cyan-500/20 opacity-75'
            }`}
          />

          {/* Outer rotating holographic ring */}
          <svg
            viewBox="0 0 200 200"
            className={`absolute inset-0 w-full h-full ${outerSpinClass}`}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id="holoRingOuter" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.95" />
                <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#a855f7" stopOpacity="0.95" />
              </linearGradient>
            </defs>
            <circle
              cx="100"
              cy="100"
              r="95"
              fill="none"
              stroke="url(#holoRingOuter)"
              strokeWidth="2.5"
              strokeDasharray="42 12 16 12"
            />
            <circle
              cx="100"
              cy="100"
              r="88"
              fill="none"
              stroke="#38bdf8"
              strokeOpacity="0.35"
              strokeWidth="1"
              strokeDasharray="4 6"
            />
          </svg>

          {/* Counter-rotating inner ring */}
          <svg
            viewBox="0 0 200 200"
            className={`absolute inset-2 w-[calc(100%-16px)] h-[calc(100%-16px)] ${innerSpinClass}`}
            aria-hidden="true"
          >
            <circle
              cx="100"
              cy="100"
              r="92"
              fill="none"
              stroke={status === 'thinking' ? '#c084fc' : '#06b6d4'}
              strokeOpacity="0.7"
              strokeWidth="2"
              strokeDasharray="24 18 8 18"
            />
          </svg>

          {/* Portrait core */}
          <div className="relative w-[78%] h-[78%] rounded-full overflow-hidden border-2 border-cyan-400/70 shadow-[0_0_28px_rgba(34,211,238,0.45)] bg-slate-950">
            {!imgFailed ? (
              <img
                src="/assets/nazia-portrait.png"
                alt="Nazia AI Hologram"
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="w-full h-full object-cover object-top scale-105 group-hover:scale-110 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-cyan-950 via-slate-950 to-violet-950 text-cyan-300">
                <Sparkles className="w-8 h-8 mb-1" />
                <span className="text-xs font-semibold tracking-wider">NAZIA</span>
              </div>
            )}

            {/* Holographic Eyes Scanner Sweep when Vision/Aankhein are ON */}
            {eyesActive && (
              <div
                aria-hidden="true"
                className="animate-scan-sweep absolute inset-x-0 h-6 bg-gradient-to-b from-transparent via-emerald-300/45 to-transparent pointer-events-none"
              />
            )}

            {/* Dual Holographic Eye HUD Reticles */}
            {showAnatomy && (
              <div
                aria-hidden="true"
                className="absolute inset-x-0 top-[29%] flex items-center justify-center gap-6 pointer-events-none"
              >
                {[0, 1].map((eyeIdx) => (
                  <div
                    key={eyeIdx}
                    className={`animate-eye-blink w-5 h-3.5 rounded-full border flex items-center justify-center transition-colors ${
                      eyesActive
                        ? 'border-emerald-300 bg-emerald-400/20 shadow-[0_0_12px_rgba(52,211,153,0.9)]'
                        : 'border-cyan-300/70 bg-cyan-400/10 shadow-[0_0_8px_rgba(34,211,238,0.6)]'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        eyesActive ? 'bg-emerald-300' : 'bg-cyan-200'
                      }`}
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Subtle holographic scan tint */}
            <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 via-transparent to-violet-500/10 pointer-events-none" />
          </div>

          {/* Floating Aankhein Label Badge above ring when anatomy visible */}
          {showAnatomy && (
            <span
              className={`absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-md border text-[10px] font-medium tracking-wide bg-slate-950/90 ${
                eyesActive
                  ? 'border-emerald-400/70 text-emerald-300'
                  : 'border-cyan-500/40 text-cyan-300'
              }`}
            >
              Aankhein: {eyesActive ? 'Dekh rahi hai' : 'Ready'}
            </span>
          )}
        </button>

        {/* Right Holographic Ear (Kaan) */}
        {showAnatomy && (
          <div
            aria-label="Nazia Right Ear Sensor"
            className="ml-1 sm:ml-2 flex flex-col items-center gap-1"
            style={{
              transform: `scale(${earWaveScale})`,
              transition: 'transform 120ms ease-out',
            }}
          >
            <svg viewBox="0 0 48 80" className="w-9 h-16 sm:w-11 sm:h-20" aria-hidden="true">
              <path
                d="M32 14 C44 26, 44 54, 32 66"
                fill="none"
                stroke={earsActive ? '#34d399' : '#22d3ee'}
                strokeOpacity={earsActive ? 0.95 : 0.4}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <path
                d="M24 22 C32 30, 32 50, 24 58"
                fill="none"
                stroke={earsActive ? '#6ee7b7' : '#38bdf8'}
                strokeOpacity={earsActive ? 0.9 : 0.35}
                strokeWidth="2"
                strokeLinecap="round"
              />
              <path
                d="M12 22 C20 22, 22 32, 19 40 C17 46, 19 56, 13 58 C8 59, 6 52, 8 46"
                fill="none"
                stroke={earsActive ? '#34d399' : '#38bdf8'}
                strokeWidth="2.8"
                strokeLinecap="round"
              />
              <circle
                cx="13"
                cy="40"
                r="4"
                fill={earsActive ? '#34d399' : '#22d3ee'}
                opacity={earsActive ? 0.95 : 0.55}
              />
            </svg>
            <span
              className={`text-[10px] font-medium tracking-wide ${
                earsActive ? 'text-emerald-300' : 'text-cyan-400/70'
              }`}
            >
              Kaan
            </span>
          </div>
        )}
      </div>

      {/* Holographic Hands (Hath) + Floating Virtual Keyboard for Live Typing */}
      {showAnatomy && (
        <div className="mt-2 w-full max-w-[300px] flex flex-col items-center">
          <div className="flex items-end justify-between w-full px-3">
            {/* Left Holographic Hand */}
            <svg
              viewBox="0 0 80 64"
              aria-label="Nazia Left Hand"
              className={`w-14 h-11 ${typingActive ? 'animate-hand-type-l' : 'animate-hand-idle-l'}`}
            >
              {/* Wrist & Palm */}
              <path
                d="M12 52 L24 34 L46 30 L52 44 L30 58 Z"
                fill={typingActive ? 'rgba(34,211,238,0.28)' : 'rgba(34,211,238,0.14)'}
                stroke="#22d3ee"
                strokeWidth="2"
                strokeLinejoin="round"
              />
              {/* 5 Holographic Fingers reaching toward keyboard */}
              <line x1="28" y1="33" x2="36" y2="16" stroke="#67e8f9" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="35" y1="31" x2="46" y2="13" stroke="#67e8f9" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="41" y1="31" x2="54" y2="16" stroke="#67e8f9" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="46" y1="33" x2="60" y2="21" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" />
              <line x1="48" y1="40" x2="64" y2="36" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" />
              <circle cx="38" cy="43" r="3" fill={typingActive ? '#34d399' : '#38bdf8'} />
            </svg>

            {/* Center Holographic Typing Keyboard Grid */}
            <div
              className={`px-3 py-1.5 rounded-xl border transition-all ${
                typingActive
                  ? 'border-cyan-400 bg-cyan-500/20 shadow-[0_0_20px_rgba(34,211,238,0.45)]'
                  : 'border-cyan-500/30 bg-slate-900/80'
              }`}
            >
              <div className="grid grid-cols-6 gap-1">
                {Array.from({ length: 12 }).map((_, i) => (
                  <span
                    key={i}
                    className={`w-2.5 h-1.5 rounded-[2px] transition-opacity ${
                      typingActive
                        ? i % 3 === 0
                          ? 'bg-emerald-300 animate-pulse'
                          : 'bg-cyan-300 animate-pulse'
                        : 'bg-cyan-500/40'
                    }`}
                    style={{ animationDelay: `${i * 55}ms` }}
                  />
                ))}
              </div>
              <p className="text-[9px] text-center text-cyan-200 mt-1 font-medium">
                {typingActive ? 'Hath Typing...' : 'Hath · Keyboard'}
              </p>
            </div>

            {/* Right Holographic Hand */}
            <svg
              viewBox="0 0 80 64"
              aria-label="Nazia Right Hand"
              className={`w-14 h-11 ${typingActive ? 'animate-hand-type-r' : 'animate-hand-idle-r'}`}
            >
              <path
                d="M68 52 L56 34 L34 30 L28 44 L50 58 Z"
                fill={typingActive ? 'rgba(34,211,238,0.28)' : 'rgba(34,211,238,0.14)'}
                stroke="#22d3ee"
                strokeWidth="2"
                strokeLinejoin="round"
              />
              <line x1="52" y1="33" x2="44" y2="16" stroke="#67e8f9" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="45" y1="31" x2="34" y2="13" stroke="#67e8f9" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="39" y1="31" x2="26" y2="16" stroke="#67e8f9" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="34" y1="33" x2="20" y2="21" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" />
              <line x1="32" y1="40" x2="16" y2="36" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" />
              <circle cx="42" cy="43" r="3" fill={typingActive ? '#34d399' : '#38bdf8'} />
            </svg>
          </div>
        </div>
      )}

      {/* Status text */}
      <p
        className={`mt-2 text-xs font-medium tracking-wide transition-colors ${
          typingActive
            ? 'text-cyan-200'
            : status === 'speaking'
            ? 'text-cyan-300'
            : status === 'listening'
            ? 'text-emerald-300'
            : status === 'thinking'
            ? 'text-violet-300'
            : 'text-slate-300'
        }`}
      >
        {statusLabel}
      </p>

      {/* Reactive audio waveform bars */}
      {showWaveform && (
        <div
          className="mt-1.5 flex items-center justify-center gap-1 h-5"
          aria-hidden="true"
        >
          {WAVE_BARS.map((factor, idx) => {
            const active = status === 'speaking' || status === 'listening' || typingActive;
            const heightPct =
              status === 'listening'
                ? Math.max(20, Math.min(100, (0.25 + micLevel * 1.1) * factor * 100))
                : status === 'speaking' || typingActive
                ? Math.max(25, Math.round(factor * 100))
                : status === 'thinking'
                ? 30
                : 18;
            return (
              <span
                key={idx}
                className={`w-1 rounded-full transition-all duration-150 ${
                  status === 'listening'
                    ? 'bg-emerald-400'
                    : status === 'thinking'
                    ? 'bg-violet-400'
                    : active
                    ? 'bg-cyan-400'
                    : 'bg-cyan-500/35'
                } ${status === 'speaking' || typingActive ? 'animate-pulse' : ''}`}
                style={{
                  height: `${heightPct}%`,
                  animationDelay: `${idx * 70}ms`,
                }}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
